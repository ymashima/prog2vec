public class Test {
@Override public void setId(int id){
super.setId(id);
switch (id) {
default :
case NO_ID:
break;
case R.id.octicon_account_settings:
setOcticon(IC_ACCOUNT_SETTINGS);
break;
case R.id.octicon_add:
setOcticon(IC_ADD);
break;
case R.id.octicon_add_comment:
setOcticon(IC_ADD_COMMENT);
break;
case R.id.octicon_added:
setOcticon(IC_ADDED);
break;
case R.id.octicon_admin_tools:
setOcticon(IC_ADMIN_TOOLS);
break;
case R.id.octicon_advanced_search:
setOcticon(IC_ADVANCED_SEARCH);
break;
case R.id.octicon_android:
setOcticon(IC_ANDROID);
break;
case R.id.octicon_apple:
setOcticon(IC_APPLE);
break;
case R.id.octicon_arr_collapsed:
setOcticon(IC_ARR_COLLAPSED);
break;
case R.id.octicon_arr_down:
setOcticon(IC_ARR_DOWN);
break;
case R.id.octicon_arr_expanded:
setOcticon(IC_ARR_EXPANDED);
break;
case R.id.octicon_arr_left:
setOcticon(IC_ARR_LEFT);
break;
case R.id.octicon_arr_right:
setOcticon(IC_ARR_RIGHT);
break;
case R.id.octicon_arr_right_mini:
setOcticon(IC_ARR_RIGHT_MINI);
break;
case R.id.octicon_arr_up:
setOcticon(IC_ARR_UP);
break;
case R.id.octicon_beer:
setOcticon(IC_BEER);
break;
case R.id.octicon_blacktocat:
setOcticon(IC_BLACKTOCAT);
break;
case R.id.octicon_block:
setOcticon(IC_BLOCK);
break;
case R.id.octicon_branch_create:
setOcticon(IC_BRANCH_CREATE);
break;
case R.id.octicon_branch_delete:
setOcticon(IC_BRANCH_DELETE);
break;
case R.id.octicon_brightness:
setOcticon(IC_BRIGHTNESS);
break;
case R.id.octicon_calendar:
setOcticon(IC_CALENDAR);
break;
case R.id.octicon_clipboard:
setOcticon(IC_CLIPBOARD);
break;
case R.id.octicon_clone:
setOcticon(IC_CLONE);
break;
case R.id.octicon_code:
setOcticon(IC_CODE);
break;
case R.id.octicon_code_file:
setOcticon(IC_CODE_FILE);
break;
case R.id.octicon_commit:
setOcticon(IC_COMMIT);
break;
case R.id.octicon_commit_comment:
setOcticon(IC_COMMIT_COMMENT);
break;
case R.id.octicon_confirm:
setOcticon(IC_CONFIRM);
break;
case R.id.octicon_create:
setOcticon(IC_CREATE);
break;
case R.id.octicon_credit_card:
setOcticon(IC_CREDIT_CARD);
break;
case R.id.octicon_delete:
setOcticon(IC_DELETE);
break;
case R.id.octicon_delete_note:
setOcticon(IC_DELETE_NOTE);
break;
case R.id.octicon_diff:
setOcticon(IC_DIFF);
break;
case R.id.octicon_directory:
setOcticon(IC_DIRECTORY);
break;
case R.id.octicon_discussion:
setOcticon(IC_DISCUSSION);
break;
case R.id.octicon_download:
setOcticon(IC_DOWNLOAD);
break;
case R.id.octicon_download_media:
setOcticon(IC_DOWNLOAD_MEDIA);
break;
case R.id.octicon_download_pdf:
setOcticon(IC_DOWNLOAD_PDF);
break;
case R.id.octicon_download_tag:
setOcticon(IC_DOWNLOAD_TAG);
break;
case R.id.octicon_download_text:
setOcticon(IC_DOWNLOAD_TEXT);
break;
case R.id.octicon_download_unknown:
setOcticon(IC_DOWNLOAD_UNKNOWN);
break;
case R.id.octicon_download_zip:
setOcticon(IC_DOWNLOAD_ZIP);
break;
case R.id.octicon_edit:
setOcticon(IC_EDIT);
break;
case R.id.octicon_exclamation:
setOcticon(IC_EXCLAMATION);
break;
case R.id.octicon_feed:
setOcticon(IC_FEED);
break;
case R.id.octicon_follow:
setOcticon(IC_FOLLOW);
break;
case R.id.octicon_force_push:
setOcticon(IC_FORCE_PUSH);
break;
case R.id.octicon_fork:
setOcticon(IC_FORK);
break;
case R.id.octicon_fullscreen:
setOcticon(IC_FULLSCREEN);
break;
case R.id.octicon_gift:
setOcticon(IC_GIFT);
break;
case R.id.octicon_gist:
setOcticon(IC_GIST);
break;
case R.id.octicon_gist_private:
setOcticon(IC_GIST_PRIVATE);
break;
case R.id.octicon_graph:
setOcticon(IC_GRAPH);
break;
case R.id.octicon_help:
setOcticon(IC_HELP);
break;
case R.id.octicon_horizontal_rule:
setOcticon(IC_HORIZONTAL_RULE);
break;
case R.id.octicon_info:
setOcticon(IC_INFO);
break;
case R.id.octicon_invertocat:
setOcticon(IC_INVERTOCAT);
break;
case R.id.octicon_ios:
setOcticon(IC_IOS);
break;
case R.id.octicon_issue_closed:
setOcticon(IC_ISSUE_CLOSED);
break;
case R.id.octicon_issue_comment:
setOcticon(IC_ISSUE_COMMENT);
break;
case R.id.octicon_issue_opened:
setOcticon(IC_ISSUE_OPENED);
break;
case R.id.octicon_issue_reopened:
setOcticon(IC_ISSUE_REOPENED);
break;
case R.id.octicon_jump_down:
setOcticon(IC_JUMP_DOWN);
break;
case R.id.octicon_jump_up:
setOcticon(IC_JUMP_UP);
break;
case R.id.octicon_key:
setOcticon(IC_KEY);
break;
case R.id.octicon_keyboard:
setOcticon(IC_KEYBOARD);
break;
case R.id.octicon_link:
setOcticon(IC_LINK);
break;
case R.id.octicon_location:
setOcticon(IC_LOCATION);
break;
case R.id.octicon_lock:
setOcticon(IC_LOCK);
break;
case R.id.octicon_logout:
setOcticon(IC_LOGOUT);
break;
case R.id.octicon_mail_status:
setOcticon(IC_MAIL_STATUS);
break;
case R.id.octicon_megaphone:
setOcticon(IC_MEGAPHONE);
break;
case R.id.octicon_member_added:
setOcticon(IC_MEMBER_ADDED);
break;
case R.id.octicon_member_removed:
setOcticon(IC_MEMBER_REMOVED);
break;
case R.id.octicon_merge:
setOcticon(IC_MERGE);
break;
case R.id.octicon_milestone:
setOcticon(IC_MILESTONE);
break;
case R.id.octicon_modified:
setOcticon(IC_MODIFIED);
break;
case R.id.octicon_moved:
setOcticon(IC_MOVED);
break;
case R.id.octicon_normalscreen:
setOcticon(IC_NORMALSCREEN);
break;
case R.id.octicon_notifications:
setOcticon(IC_NOTIFICATIONS);
break;
case R.id.octicon_o_list:
setOcticon(IC_O_LIST);
break;
case R.id.octicon_octocat:
setOcticon(IC_OCTOCAT);
break;
case R.id.octicon_person:
setOcticon(IC_PERSON);
break;
case R.id.octicon_pin:
setOcticon(IC_PIN);
break;
case R.id.octicon_podcast:
setOcticon(IC_PODCAST);
break;
case R.id.octicon_private_fork:
setOcticon(IC_PRIVATE_FORK);
break;
case R.id.octicon_private_mirror:
setOcticon(IC_PRIVATE_MIRROR);
break;
case R.id.octicon_private_repo:
setOcticon(IC_PRIVATE_REPO);
break;
case R.id.octicon_public_fork:
setOcticon(IC_PUBLIC_FORK);
break;
case R.id.octicon_public_mirror:
setOcticon(IC_PUBLIC_MIRROR);
break;
case R.id.octicon_public_repo:
setOcticon(IC_PUBLIC_REPO);
break;
case R.id.octicon_pull:
setOcticon(IC_PULL);
break;
case R.id.octicon_pull_request:
setOcticon(IC_PULL_REQUEST);
break;
case R.id.octicon_push:
setOcticon(IC_PUSH);
break;
case R.id.octicon_quotemark:
setOcticon(IC_QUOTEMARK);
break;
case R.id.octicon_read_note:
setOcticon(IC_READ_NOTE);
break;
case R.id.octicon_readme:
setOcticon(IC_README);
break;
case R.id.octicon_reference:
setOcticon(IC_REFERENCE);
break;
case R.id.octicon_remove_close:
setOcticon(IC_REMOVE_CLOSE);
break;
case R.id.octicon_removed:
setOcticon(IC_REMOVED);
break;
case R.id.octicon_reorder:
setOcticon(IC_REORDER);
break;
case R.id.octicon_reply:
setOcticon(IC_REPLY);
break;
case R.id.octicon_repo_forked:
setOcticon(IC_REPO_FORKED);
break;
case R.id.octicon_ruby:
setOcticon(IC_RUBY);
break;
case R.id.octicon_save_document:
setOcticon(IC_SAVE_DOCUMENT);
break;
case R.id.octicon_search_input:
setOcticon(IC_SEARCH_INPUT);
break;
case R.id.octicon_secure:
setOcticon(IC_SECURE);
break;
case R.id.octicon_star:
setOcticon(IC_STAR);
break;
case R.id.octicon_submodule:
setOcticon(IC_SUBMODULE);
break;
case R.id.octicon_sync:
setOcticon(IC_SYNC);
break;
case R.id.octicon_tag_create:
setOcticon(IC_TAG_CREATE);
break;
case R.id.octicon_tag_delete:
setOcticon(IC_TAG_DELETE);
break;
case R.id.octicon_team:
setOcticon(IC_TEAM);
break;
case R.id.octicon_text_file:
setOcticon(IC_TEXT_FILE);
break;
case R.id.octicon_time:
setOcticon(IC_TIME);
break;
case R.id.octicon_u_list:
setOcticon(IC_U_LIST);
break;
case R.id.octicon_unread_note:
setOcticon(IC_UNREAD_NOTE);
break;
case R.id.octicon_unwatch:
setOcticon(IC_UNWATCH);
break;
case R.id.octicon_upload:
setOcticon(IC_UPLOAD);
break;
case R.id.octicon_version:
setOcticon(IC_VERSION);
break;
case R.id.octicon_watchers:
setOcticon(IC_WATCHERS);
break;
case R.id.octicon_watching:
setOcticon(IC_WATCHING);
break;
case R.id.octicon_wiki:
setOcticon(IC_WIKI);
break;
case R.id.octicon_windows:
setOcticon(IC_WINDOWS);
break;
case R.id.octicon_wrench:
setOcticon(IC_WRENCH);
break;
}
}
}
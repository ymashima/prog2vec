public class Test {
public void setId(String id) throws FormatException, IOException {
super.setId(id);
savedbLength=new Vector<Long>();
if (out.length() > 0) {
RandomAccessInputStream in=new RandomAccessInputStream(currentId);
in.order(true);
in.seek(FRAME_OFFSET);
planesWritten=in.readInt();
in.seek(SAVE_FILE_SIZE);
endPos=in.readInt() + SAVE_FILE_SIZE + 4;
in.seek(SAVE_LIST2_SIZE);
idx1Pos=in.readInt() + SAVE_LIST2_SIZE + 4;
saveidx1Length=idx1Pos + 4;
if (planesWritten > 0)     in.seek(saveidx1Length + 4);
for (int z=0; z < planesWritten; z++) {
in.skipBytes(8);
savedbLength.add(in.readInt() + 4 + SAVE_MOVI);
in.skipBytes(4);
}
in.close();
out.seek(idx1Pos);
}
out.order(true);
MetadataRetrieve meta=getMetadataRetrieve();
tDim=meta.getPixelsSizeZ(series).getValue().intValue();
zDim=meta.getPixelsSizeT(series).getValue().intValue();
yDim=meta.getPixelsSizeY(series).getValue().intValue();
xDim=meta.getPixelsSizeX(series).getValue().intValue();
String type=meta.getPixelsType(series).toString();
int pixelType=FormatTools.pixelTypeFromString(type);
bytesPerPixel=FormatTools.getBytesPerPixel(pixelType);
bytesPerPixel*=getSamplesPerPixel();
xPad=0;
int xMod=xDim % 4;
if (xMod != 0) {
xPad=4 - xMod;
xDim+=xPad;
}
byte[][] lut=null;
if (getColorModel() instanceof IndexColorModel) {
lut=new byte[4][256];
IndexColorModel model=(IndexColorModel)getColorModel();
model.getReds(lut[0]);
model.getGreens(lut[1]);
model.getBlues(lut[2]);
model.getAlphas(lut[3]);
}
if (out.length() == 0) {
out.writeBytes("RIFF");
out.writeInt(0);
out.writeBytes("AVI ");
out.writeBytes("LIST");
out.writeInt((bytesPerPixel == 1) ? 1240 : 216);
out.writeBytes("hdrl");
out.writeBytes("avih");
out.writeInt(0x38);
microSecPerFrame=(int)(1.0 / fps * 1.0e6);
out.writeInt(microSecPerFrame);
out.writeInt(0);
out.writeInt(0);
out.writeInt(0x10);
out.writeInt(0);
out.writeInt(0);
out.writeInt(1);
out.writeInt(0);
out.writeInt(xDim - xPad);
out.writeInt(yDim);
out.writeInt(0);
out.writeInt(0);
out.writeInt(0);
out.writeInt(0);
out.writeBytes("LIST");
out.writeInt((bytesPerPixel == 1) ? 1164 : 140);
out.writeBytes("strl");
out.writeBytes("strh");
out.writeInt(56);
out.writeBytes("vids");
out.writeBytes("DIB ");
out.writeInt(0);
out.writeInt(0);
out.writeInt(0);
out.writeInt(1);
out.writeInt(fps);
out.writeInt(0);
out.writeInt(tDim * zDim);
out.writeInt(0);
out.writeInt(-1);
out.writeInt(0);
out.writeShort((short)0);
out.writeShort((short)0);
out.writeShort((short)0);
out.writeShort((short)0);
out.writeBytes("strf");
out.writeInt((bytesPerPixel == 1) ? 1068 : 44);
out.writeInt(40);
out.writeInt(xDim);
out.writeInt(yDim);
out.writeShort(1);
int bitsPerPixel=(bytesPerPixel == 3) ? 24 : 8;
out.writeShort((short)bitsPerPixel);
out.writeInt(0);
out.writeInt(0);
out.writeInt(0);
out.writeInt(0);
int nColors=256;
out.writeInt(nColors);
out.writeInt(0);
if (bytesPerPixel == 1) {
if (lut != null) {
for (int i=0; i < 256; i++) {
out.write(lut[2][i]);
out.write(lut[1][i]);
out.write(lut[0][i]);
out.write(lut[3][i]);
}
}
else {
byte[] lutWrite=new byte[4 * 256];
for (int i=0; i < 256; i++) {
lutWrite[4 * i]=(byte)i;
lutWrite[4 * i + 1]=(byte)i;
lutWrite[4 * i + 2]=(byte)i;
lutWrite[4 * i + 3]=0;
}
out.write(lutWrite);
}
}
out.seek(SAVE_STRF_SIZE);
out.writeInt((int)(SAVE_STRN_POS - (SAVE_STRF_SIZE + 4)));
out.seek(SAVE_STRN_POS);
out.writeBytes("strn");
out.writeInt(16);
out.writeBytes("FileAVI write  ");
out.seek(SAVE_LIST1_SIZE);
out.writeInt((int)(SAVE_JUNK_SIG - (SAVE_LIST1_SIZE + 4)));
out.seek(SAVE_LIST1_SUBSIZE);
out.writeInt((int)(SAVE_JUNK_SIG - (SAVE_LIST1_SUBSIZE + 4)));
out.seek(SAVE_JUNK_SIG);
out.writeBytes("JUNK");
out.writeInt((int)PADDING_BYTES);
for (int i=0; i < PADDING_BYTES / 2; i++) {
out.writeShort((short)0);
}
out.writeBytes("LIST");
out.writeInt(4);
out.writeBytes("movi");
idx1Pos=out.getFilePointer();
}
}
}
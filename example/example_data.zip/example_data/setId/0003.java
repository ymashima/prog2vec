public class Test {
public void setId(String id) throws FormatException, IOException {
super.setId(id);
MetadataStore store=getMetadataStore();
if (!(store instanceof IMetadata) || reader.getSeriesCount() == 1) {
tileX=1;
tileY=1;
return;
}
IMetadata meta=(IMetadata)store;
if (meta.getPlateCount() > 1 || (meta.getPlateCount() == 1 && meta.getWellCount(0) > 1)) {
tileX=1;
tileY=1;
return;
}
boolean equalDimensions=true;
for (int i=1; i < meta.getImageCount(); i++) {
if (!meta.getPixelsSizeX(i).equals(meta.getPixelsSizeX(0))) {
equalDimensions=false;
}
if (!meta.getPixelsSizeY(i).equals(meta.getPixelsSizeY(0))) {
equalDimensions=false;
}
if (!meta.getPixelsSizeZ(i).equals(meta.getPixelsSizeZ(0))) {
equalDimensions=false;
}
if (!meta.getPixelsSizeC(i).equals(meta.getPixelsSizeC(0))) {
equalDimensions=false;
}
if (!meta.getPixelsSizeT(i).equals(meta.getPixelsSizeT(0))) {
equalDimensions=false;
}
if (!meta.getPixelsType(i).equals(meta.getPixelsType(0))) {
equalDimensions=false;
}
if (!equalDimensions)     break;
}
if (!equalDimensions) {
tileX=1;
tileY=1;
return;
}
ArrayList<TileCoordinate> tiles=new ArrayList<TileCoordinate>();
ArrayList<Double> uniqueX=new ArrayList<Double>();
ArrayList<Double> uniqueY=new ArrayList<Double>();
boolean equalZs=true;
Double firstZ=meta.getPlanePositionZ(0,meta.getPlaneCount(0) - 1);
for (int i=0; i < reader.getSeriesCount(); i++) {
TileCoordinate coord=new TileCoordinate();
coord.x=meta.getPlanePositionX(i,meta.getPlaneCount(i) - 1);
coord.y=meta.getPlanePositionY(i,meta.getPlaneCount(i) - 1);
tiles.add(coord);
if (coord.x != null && !uniqueX.contains(coord.x)) {
uniqueX.add(coord.x);
}
if (coord.y != null && !uniqueY.contains(coord.y)) {
uniqueY.add(coord.y);
}
Double zPos=meta.getPlanePositionZ(i,meta.getPlaneCount(i) - 1);
if (firstZ == null) {
if (zPos != null) {
equalZs=false;
}
}
else {
if (!firstZ.equals(zPos)) {
equalZs=false;
}
}
}
tileX=uniqueX.size();
tileY=uniqueY.size();
if (!equalZs) {
tileX=1;
tileY=1;
return;
}
tileMap=new Integer[tileY][tileX];
Double[] xCoordinates=uniqueX.toArray(new Double[tileX]);
Arrays.sort(xCoordinates);
Double[] yCoordinates=uniqueY.toArray(new Double[tileY]);
Arrays.sort(yCoordinates);
for (int row=0; row < tileMap.length; row++) {
for (int col=0; col < tileMap[row].length; col++) {
TileCoordinate coordinate=new TileCoordinate();
coordinate.x=xCoordinates[col];
coordinate.y=yCoordinates[row];
for (int tile=0; tile < tiles.size(); tile++) {
if (tiles.get(tile).equals(coordinate)) {
tileMap[row][col]=tile;
}
}
}
}
}
}
public class Test {
public void setId(String id) throws FormatException, IOException {
super.setId(id);
if (checkSuffix(currentId,"ids")) {
String metadataFile=currentId.substring(0,currentId.lastIndexOf("."));
metadataFile+=".ics";
out.close();
out=new RandomAccessOutputStream(metadataFile);
}
if (out.length() == 0) {
out.writeBytes("\t\n");
if (checkSuffix(id,"ids")) {
out.writeBytes("ics_version\t1.0\n");
}
else {
out.writeBytes("ics_version\t2.0\n");
}
out.writeBytes("filename\t" + currentId + "\n");
out.writeBytes("layout\tparameters\t6\n");
MetadataRetrieve meta=getMetadataRetrieve();
MetadataTools.verifyMinimumPopulated(meta,series);
int pixelType=FormatTools.pixelTypeFromString(meta.getPixelsType(series).toString());
dimensionOffset=out.getFilePointer();
int[] sizes=overwriteDimensions(meta);
dimensionLength=(int)(out.getFilePointer() - dimensionOffset);
if (validBits != 0) {
out.writeBytes("layout\tsignificant_bits\t" + validBits + "\n");
}
boolean signed=FormatTools.isSigned(pixelType);
boolean littleEndian=!meta.getPixelsBinDataBigEndian(series,0).booleanValue();
out.writeBytes("representation\tformat\t" + (pixelType == FormatTools.FLOAT ? "real\n" : "integer\n"));
out.writeBytes("representation\tsign\t" + (signed ? "signed\n" : "unsigned\n"));
out.writeBytes("representation\tcompression\tuncompressed\n");
out.writeBytes("representation\tbyte_order\t");
for (int i=0; i < sizes[0] / 8; i++) {
if (littleEndian) {
out.writeBytes((i + 1) + "\t");
}
else {
out.writeBytes(((sizes[0] / 8) - i) + "\t");
}
}
out.writeBytes("\nparameter\tscale\t1.000000\t");
StringBuffer units=new StringBuffer();
for (int i=0; i < outputOrder.length(); i++) {
char dim=outputOrder.charAt(i);
Number value=1.0;
if (dim == 'X') {
if (meta.getPixelsPhysicalSizeX(0) != null) {
value=meta.getPixelsPhysicalSizeX(0).getValue();
}
units.append("micrometers\t");
}
else       if (dim == 'Y') {
if (meta.getPixelsPhysicalSizeY(0) != null) {
value=meta.getPixelsPhysicalSizeY(0).getValue();
}
units.append("micrometers\t");
}
else       if (dim == 'Z') {
if (meta.getPixelsPhysicalSizeZ(0) != null) {
value=meta.getPixelsPhysicalSizeZ(0).getValue();
}
units.append("micrometers\t");
}
else       if (dim == 'T') {
value=meta.getPixelsTimeIncrement(0);
units.append("seconds\t");
}
out.writeBytes(value + "\t");
}
out.writeBytes("\nparameter\tunits\tbits\t" + units.toString() + "\n");
out.writeBytes("\nend\n");
pixelOffset=out.getFilePointer();
}
else   if (checkSuffix(currentId,"ics")) {
RandomAccessInputStream in=new RandomAccessInputStream(currentId);
in.findString("\nend\n");
pixelOffset=in.getFilePointer();
in.close();
}
if (checkSuffix(currentId,"ids")) {
pixelOffset=0;
}
if (pixels == null) {
pixels=new RandomAccessOutputStream(currentId);
}
}
}
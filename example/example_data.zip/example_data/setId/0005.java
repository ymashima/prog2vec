public class Test {
public void setId(String id) throws FormatException, IOException {
try {
super.setId(id);
}
catch (  CMMException e) {
in=new RandomAccessInputStream(id);
ByteArrayOutputStream v=new ByteArrayOutputStream();
byte[] tag=new byte[2];
in.read(tag);
v.write(tag);
in.read(tag);
int tagValue=DataTools.bytesToShort(tag,false) & 0xffff;
boolean appNoteFound=false;
while (tagValue != 0xffdb) {
if (!appNoteFound || (tagValue < 0xffe0 && tagValue >= 0xfff0)) {
v.write(tag);
in.read(tag);
int len=DataTools.bytesToShort(tag,false) & 0xffff;
byte[] tagContents=new byte[len - 2];
in.read(tagContents);
v.write(tag);
v.write(tagContents);
}
else {
in.read(tag);
int len=DataTools.bytesToShort(tag,false) & 0xffff;
in.skipBytes(len - 2);
}
if (tagValue >= 0xffe0 && tagValue < 0xfff0 && !appNoteFound) {
appNoteFound=true;
}
in.read(tag);
tagValue=DataTools.bytesToShort(tag,false) & 0xffff;
}
v.write(tag);
byte[] remainder=new byte[(int)(in.length() - in.getFilePointer())];
in.read(remainder);
v.write(remainder);
ByteArrayHandle bytes=new ByteArrayHandle(v.toByteArray());
Location.mapFile(currentId + ".fixed",bytes);
super.setId(currentId + ".fixed");
}
if (getSizeX() > MAX_SIZE && getSizeY() > MAX_SIZE && !legacyReaderInitialized) {
close();
useLegacy=true;
super.setId(id);
}
}
}
public class Test {
public void setId(String id) throws FormatException, IOException {
super.setId(id);
if (useLegacy) {
try {
legacyReader.setId(id);
legacyReaderInitialized=true;
}
catch (    FormatException e) {
LOGGER.debug("",e);
nativeReader.setId(id);
nativeReaderInitialized=true;
}
}
else {
Exception exc=null;
try {
nativeReader.setId(id);
nativeReaderInitialized=true;
}
catch (    FormatException e) {
exc=e;
}
catch (    IOException e) {
exc=e;
}
if (exc != null) {
nativeReaderInitialized=false;
LOGGER.debug("",exc);
legacyReader.setId(id);
legacyReaderInitialized=true;
}
if (legacyReaderInitialized) {
nativeReaderInitialized=false;
}
}
if (nativeReaderInitialized) {
core=nativeReader.getCoreMetadata();
metadata=nativeReader.getGlobalMetadata();
metadataStore=nativeReader.getMetadataStore();
}
if (legacyReaderInitialized) {
core=legacyReader.getCoreMetadata();
metadata=legacyReader.getGlobalMetadata();
metadataStore=legacyReader.getMetadataStore();
}
}
}
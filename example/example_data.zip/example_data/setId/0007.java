public class Test {
public void setId(String id) throws FormatException, IOException {
super.setId(id);
if (out.length() == 0) {
MetadataRetrieve r=getMetadataRetrieve();
int width=r.getPixelsSizeX(series).getValue().intValue();
int height=r.getPixelsSizeY(series).getValue().intValue();
int bytesPerPixel=FormatTools.getBytesPerPixel(r.getPixelsType(series).toString());
int nChannels=getSamplesPerPixel();
boolean indexed=getColorModel() != null && (getColorModel() instanceof IndexColorModel);
littleEndian=!r.getPixelsBinDataBigEndian(series,0);
out.write(PNG_SIG);
out.writeInt(13);
byte[] b=new byte[17];
b[0]='I';
b[1]='H';
b[2]='D';
b[3]='R';
DataTools.unpackBytes(width,b,4,4,false);
DataTools.unpackBytes(height,b,8,4,false);
b[12]=(byte)(bytesPerPixel * 8);
if (indexed)     b[13]=(byte)3;
else     if (nChannels == 1)     b[13]=(byte)0;
else     if (nChannels == 2)     b[13]=(byte)4;
else     if (nChannels == 3)     b[13]=(byte)2;
else     if (nChannels == 4)     b[13]=(byte)6;
b[14]=(byte)0;
b[15]=(byte)0;
b[16]=(byte)0;
out.write(b);
out.writeInt(crc(b));
out.writeInt(8);
out.writeBytes("acTL");
numFramesPointer=out.getFilePointer();
out.writeInt(0);
out.writeInt(0);
out.writeInt(0);
}
}
}
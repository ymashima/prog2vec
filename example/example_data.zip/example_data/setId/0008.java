public class Test {
@Override public void setId(String id) throws IllegalArgumentException {
if (fixedId != null) {
if (!id.toLowerCase().equals(fixedId.toLowerCase())) {
throw new IllegalArgumentException(I18N.getString("orbisgis.org.orbigis.leafElement.thisElementCannot") + I18N.getString("orbisgis.org.orbigis.leafElement.haveAnIdDifferentThan") + fixedId);
}
else {
try {
element.idChanged(id);
this.id=id;
fireIdChanged();
}
catch (      GeocognitionException e) {
throw new IllegalArgumentException(I18N.getString("orbisgis.org.orbigis.leafElement.cannotChangeId"),e);
}
}
}
else {
try {
GeocognitionElement parent=getParent();
if (parent != null) {
for (int i=0; i < parent.getElementCount(); i++) {
GeocognitionElement child=parent.getElement(i);
if (child != this) {
if (child.getId().toLowerCase().equals(id.toLowerCase())) {
throw new GeocognitionException(I18N.getString("orbisgis.org.orbigis.leafElement.thereIsAlready") + I18N.getString("orbisgis.org.orbigis.leafElement.anElementWithTheId") + id);
}
}
}
}
element.idChanged(id);
this.id=id;
fireIdChanged();
}
catch (    GeocognitionException e) {
throw new IllegalArgumentException(I18N.getString("orbisgis.org.orbigis.leafElement.cannotChangeId"),e);
}
}
}
}
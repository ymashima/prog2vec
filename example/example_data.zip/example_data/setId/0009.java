public class Test {
public void setId(String id) throws FormatException, IOException {
if (!id.equals(currentId)) {
initFile(id);
if (saveOriginalMetadata) {
MetadataStore store=getMetadataStore();
if (store instanceof OMEXMLMetadata) {
try {
if (factory == null)           factory=new ServiceFactory();
if (service == null) {
service=factory.getInstance(OMEXMLService.class);
}
Hashtable<String,Object> allMetadata=new Hashtable<String,Object>();
allMetadata.putAll(metadata);
for (int series=0; series < getSeriesCount(); series++) {
String name="Series " + series;
try {
String realName=((IMetadata)store).getImageName(series);
if (realName != null && realName.trim().length() != 0) {
name=realName;
}
}
catch (            Exception e) {
}
setSeries(series);
MetadataTools.merge(getSeriesMetadata(),allMetadata,name + " ");
}
setSeries(0);
service.populateOriginalMetadata((OMEXMLMetadata)store,allMetadata);
}
catch (        DependencyException e) {
LOGGER.warn("OMEXMLService not available.",e);
}
}
}
}
}
}
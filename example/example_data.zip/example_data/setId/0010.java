public class Test {
public void setId(String id){
if (id == null)   id="";
if (!id.equals(_id)) {
final boolean rawId=this instanceof RawId;
String newUuid=null;
if (rawId)     newUuid=id;
if (id.length() > 0) {
if (Names.isReserved(id))       throw new UiException("Invalid ID: " + id + ". Cause: reserved words not allowed: "+ Names.getReservedNames());
if (rawId && _page != null) {
final Component c=_page.getDesktop().getComponentByUuidIfAny(newUuid);
if (c != null && c != this)         throw new UiException("Replicated UUID is not allowed for " + getClass() + ": "+ newUuid);
}
checkIdSpaces(this,id);
}
removeFromIdSpaces(this);
if (rawId) {
if (_page != null) {
final Desktop dt=_page.getDesktop();
((DesktopCtrl)dt).removeComponent(this,false);
if (newUuid.length() == 0)         newUuid=nextUuid(dt);
if (!Objects.equals(_uuid,newUuid))         getAttachedUiEngine().addUuidChanged(this);
}
_id=id;
_uuid=newUuid;
if (_page != null) {
((DesktopCtrl)_page.getDesktop()).addComponent(this);
}
}
else {
_id=id;
}
addToIdSpaces(this);
smartUpdate("id",_id);
}
}
}
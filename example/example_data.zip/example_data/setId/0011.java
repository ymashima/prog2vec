public class Test {
public void setId(String id) throws FormatException, IOException {
super.setId(id);
MetadataRetrieve r=getMetadataRetrieve();
MetadataTools.verifyMinimumPopulated(r,series);
int width=r.getPixelsSizeX(series).getValue().intValue();
int height=r.getPixelsSizeY(series).getValue().intValue();
int nChannels=getSamplesPerPixel();
int planeSize=width * height * nChannels;
pad=nChannels > 1 ? 0 : (4 - (width % 4)) % 4;
if (legacy == null) {
legacy=new LegacyQTWriter();
legacy.setCodec(codec);
legacy.setMetadataRetrieve(r);
}
offsets=new Vector<Integer>();
created=(int)System.currentTimeMillis();
numBytes=0;
if (out.length() == 0) {
writeAtom(8,"wide");
writeAtom(numBytes + 8,"mdat");
}
else {
out.seek(BYTE_COUNT_OFFSET);
RandomAccessInputStream in=new RandomAccessInputStream(currentId);
in.seek(BYTE_COUNT_OFFSET);
numBytes=in.readInt() - 8;
in.close();
}
for (int i=0; i < getPlaneCount(); i++) {
offsets.add(16 + i * (planeSize + pad * height));
}
}
}
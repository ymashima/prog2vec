public class Test {
public void setId(String id){
if (this.isBuilt)   throw new IllegalStateException("This DatasetNodeBuilder has been finished().");
if (this.id != null) {
if (!this.id.equals(id)) {
if (this.isDatasetIdInUseGlobally(id))       throw new IllegalStateException();
if (this.parentDatasetContainer != null) {
this.parentDatasetContainer.removeDatasetNodeByGloballyUniqueId(this.id);
this.parentDatasetContainer.removeDatasetNodeFromLocalById(this.id);
}
if (id == null) {
this.id=null;
return;
}
this.id=id;
if (this.parentDatasetContainer != null) {
this.parentDatasetContainer.addDatasetNodeByGloballyUniqueId(this);
this.parentDatasetContainer.addDatasetNodeToLocalById(this);
}
}
else {
}
}
else {
if (id == null)     return;
if (this.isDatasetIdInUseGlobally(id))     throw new IllegalStateException();
this.id=id;
if (this.parentDatasetContainer != null) {
this.parentDatasetContainer.addDatasetNodeByGloballyUniqueId(this);
this.parentDatasetContainer.addDatasetNodeToLocalById(this);
}
}
}
}
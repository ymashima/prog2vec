public class Test {
public int setId(int id){
int tmp=_id;
_id=id;
if (tmp < 0) {
if (_showFrom == null) {
TASKS.put(id,this);
}
else {
Calendar now=Calendar.getInstance();
Calendar cmp=Calendar.getInstance();
long nowm, cmpm;
cmp.setTime(_showFrom);
cmp.set(Calendar.HOUR_OF_DAY,0);
cmp.set(Calendar.MINUTE,0);
cmp.set(Calendar.SECOND,0);
cmp.set(Calendar.MILLISECOND,0);
now.set(Calendar.HOUR_OF_DAY,0);
now.set(Calendar.MINUTE,0);
now.set(Calendar.SECOND,0);
now.set(Calendar.MILLISECOND,0);
nowm=now.getTimeInMillis();
cmpm=cmp.getTimeInMillis();
if (cmpm <= nowm) {
TASKS.put(id,this);
}
}
}
return tmp;
}
}
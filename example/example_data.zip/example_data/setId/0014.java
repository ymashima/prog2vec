public class Test {
private void setId(Integer id,final String url,Boolean isAdmin){
Anchor anchor;
if (!isAdmin)   if (Window.Location.getHash().equals("#admin"))   isAdmin=true;
if (isAdmin)   anchor=new Anchor("javascript:void;");
else   anchor=new Anchor(url);
anchor.setText(id.toString());
if (isAdmin)   anchor.addClickHandler(new ClickHandler(){
@Override public void onClick(    ClickEvent event){
new EditInfoWindow(currentEdit,url);
}
}
);
RootPanel.get("editid").clear();
RootPanel.get("editid").add(anchor);
if (isAdmin) {
final TextBox gotoId=new TextBox();
gotoId.addKeyPressHandler(new KeyPressHandler(){
@Override public void onKeyPress(      KeyPressEvent event){
if (event.getCharCode() == 13)         gotoPage(new Integer(gotoId.getText()));
}
}
);
RootPanel.get("goto").clear();
RootPanel.get("goto").add(gotoId);
}
}
}
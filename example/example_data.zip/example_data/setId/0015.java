public class Test {
/**
* Sets the ino:id for the XML instance.
*/
public void setId(String inoId){
if (inoId == null || inoId.length() == 0) {
if (element == null)     super.setId(null);
else {
QName qtmpName=new QName(TInoNamespace.ID.getName(),inoNamespace);
Attribute tmpAttribute=new FlyweightAttribute(qtmpName);
element.remove(tmpAttribute);
}
}
else {
if (element == null)     super.setId(inoId);
else {
QName qname=new QName(TInoNamespace.ID.getName(),inoNamespace);
Attribute att=element.attribute(qname);
if (att != null)       att.setValue(inoId);
else {
att=new FlyweightAttribute(TInoNamespace.ID.getName(),inoId,inoNamespace);
element.add(att);
}
}
}
}
}
public class Test {
/**
* HACK: This method mainly exists to prompt the user for a missing LuraWave license code, in the case of LWF-compressed Flex.
* @see ImagePlusReader#readProcessors(ImportProcess,int,Region)
*/
private void setId() throws FormatException, IOException {
boolean first=true;
for (int i=0; i < LuraWave.MAX_TRIES; i++) {
String code=LuraWave.initLicenseCode();
try {
reader.setId(options.getId());
return;
}
catch (    FormatException exc) {
if (options.isQuiet() || options.isWindowless())       throw exc;
if (!LuraWave.isLicenseCodeException(exc))       throw exc;
code=LuraWave.promptLicenseCode(code,first);
if (code == null)       throw exc;
if (first)       first=false;
reader.close();
}
}
throw new FormatException(LuraWave.TOO_MANY_TRIES);
}
}
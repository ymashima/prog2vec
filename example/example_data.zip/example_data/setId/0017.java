public class Test {
/**
* Set this task's ID string. The ID is defined in the plugin's extension point contribution to org.eclipse.bpmn2.modeler.custom_task. This will register the Custom Task with the BPMN Feature Provider.
* @param fp - Feature Provider (must be a BPMNFeatureProvider)
* @param id - the task ID string.
* @throws Exception Custom Task ID can not be null The Feature Provider is invalid (not a BPMNFeatureProvider) Attempt to add a Custom Feature with a duplicate ID {id}
*/
public void setId(IFeatureProvider fp,String id) throws Exception {
if (id == null || id.isEmpty()) {
throw new Exception("Custom Task ID can not be null");
}
this.id=id;
if (fp instanceof BPMNFeatureProvider) {
BPMNFeatureProvider bfp=(BPMNFeatureProvider)fp;
try {
bfp.addFeatureContainer(this);
}
catch (    Exception e) {
e.printStackTrace();
}
}
else   throw new Exception("The Feature Provider is invalid (not a BPMNFeatureProvider)");
}
}
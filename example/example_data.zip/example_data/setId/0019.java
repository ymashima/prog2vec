public class Test {
private void setId(IEntity entity){
if (entity.getId() == null) {
long id;
IDGenerator idGenerator=getIDGenerator();
if (idGenerator instanceof DB4OIDGenerator)     id=((DB4OIDGenerator)idGenerator).getNext(false);
else     id=idGenerator.getNext();
if (entity instanceof News) {
News n=(News)entity;
n.releaseReadLockSpecial();
try {
entity.setId(id);
}
finally {
n.acquireReadLockSpecial();
}
}
else {
entity.setId(id);
}
}
}
}
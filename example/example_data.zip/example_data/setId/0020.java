public class Test {
public void setId(String id) throws FormatException, IOException {
super.setId(id);
MetadataRetrieve retrieve=getMetadataRetrieve();
String xml;
try {
ServiceFactory factory=new ServiceFactory();
service=factory.getInstance(OMEXMLService.class);
xml=service.getOMEXML(retrieve);
}
catch (  DependencyException de) {
throw new MissingLibraryException(OMEXMLServiceImpl.NO_OME_XML_MSG,de);
}
catch (  ServiceException se) {
throw new FormatException(se);
}
xmlFragments=new Vector<String>();
currentFragment="<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
XMLTools.parseXML(xml,new OMEHandler());
xmlFragments.add(currentFragment);
}
}
public class Test {
@Override public void setId(Object object,String id) throws ObjectContextMappingException {
PropertyDescriptor property=attributes.getProperty(object.getClass(),"_id");
if (property != null) {
Exception exception=null;
try {
property.getWriteMethod().invoke(object,id);
return;
}
catch (    IllegalArgumentException e) {
exception=e;
}
catch (    IllegalAccessException e) {
exception=e;
}
catch (    InvocationTargetException e) {
exception=e;
}
throw new ObjectContextMappingException(object.getClass(),exception);
}
}
}
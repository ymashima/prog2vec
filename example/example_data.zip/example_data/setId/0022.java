public class Test {
public IRIElement setId(String value,boolean normalize){
complete();
if (value == null) {
_removeChildren(ID,false);
return null;
}
IRIElement id=getIdElement();
if (id != null) {
if (normalize)     id.setNormalizedValue(value);
else     id.setValue(value);
return id;
}
else {
FOMFactory fomfactory=(FOMFactory)factory;
IRIElement iri=fomfactory.newID(this);
iri.setValue((normalize) ? IRI.normalizeString(value) : value);
return iri;
}
}
}
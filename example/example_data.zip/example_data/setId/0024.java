public class Test {
/**
* Sets the value of the id property.
* @param value allowed object is {@link Id }
*/
public void setId(Id value){
Id existingId=getId();
if (existingId != null) {
if (!existingId.equals(value)) {
log.debug("Changing SDT ID from " + existingId + " to "+ value);
rPrOrAliasOrLock.remove(existingId);
if (value != null) {
rPrOrAliasOrLock.add(value);
}
}
}
else   if (value != null) {
rPrOrAliasOrLock.add(value);
}
}
}
public class Test {
/**
* Decomposes a JsonNode from Jackson into an ID and stores it.
* @param metaDataNode The meta-data node from an upload.
* @throws DomainException Never thrown.
*/
public void setId(final JsonNode metaDataNode) throws DomainException {
if (metaDataNode == null) {
return;
}
if (metaDataNode.has("id")) {
JsonNode idNode=metaDataNode.get("id");
if (idNode.isValueNode()) {
this.id=idNode.asText();
}
else {
throw new DomainException("The 'id' is not a value.");
}
}
}
}
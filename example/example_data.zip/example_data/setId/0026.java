public class Test {
/**
* Sets the ID of the Content Specification.
* @param id The database ID of the content specification.
*/
public void setId(final int id){
if (this.id == null) {
this.id=new KeyValueNode<Integer>("ID",id);
appendChild(this.id);
nodes.addFirst(this.id);
if (this.id.getParent() != null) {
this.id.removeParent();
}
this.id.setParent(this);
}
else {
this.id.setValue(id);
}
}
}
public class Test {
public void setId(String id){
if (consumer != null) {
ProducerInfo info=getProducerInfo();
String oldId=info.getId();
if (isOldAndNewDifferent(oldId,id)) {
id=checkNameValidity(id,"edit-cons-form:id");
if (id != null) {
info.setId(id);
getRegistry().updateProducerInfo(info);
modified=true;
this.id=id;
}
}
}
else {
resolveConsumer(id);
}
}
}
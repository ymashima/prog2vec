public class Test {
/**
* Set the Id of an  {@link Object} (a {@link j2jId} must be defined)
* @param o
* @param id
*/
public static Object setId(Object o,URI id){
j2jId ano=o.getClass().getAnnotation(j2jId.class);
Object[] args={id};
if (ano != null) {
try {
o.getClass().getMethod(ano.setMethod(),URI.class).invoke(o,args);
}
catch (    Exception e) {
throw new RuntimeException("Error setting ID of " + o,e);
}
}
return o;
}
}
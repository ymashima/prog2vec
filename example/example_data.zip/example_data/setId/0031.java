public class Test {
/**
* Example of using an anonymous inner class (the WidgetProcessor) tied to an outer class method.
*/
UIComponent setId(UIComponent widget,UIMetawidget metawidget){
if (widget.getId() != null && widget.getId().startsWith("binding")) {
throw new RuntimeException("Id is '" + widget.getId() + "'. ReadableIdProcessor still active?");
}
if (widget instanceof HtmlInputText || widget instanceof HtmlInputTextarea) {
widget.setId("child" + metawidget.getChildren().size());
}
else   if (widget instanceof UIMetawidget || widget instanceof UICommand || widget instanceof UIStub) {
widget.setId(FacesUtils.createUniqueId());
}
else {
throw new RuntimeException("Unexpected widget of " + widget.getClass());
}
return widget;
}
}
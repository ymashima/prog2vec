public class Test {
/**
* @param id
*/
@Override public void setId(String id){
String oldId=getId();
IState oldStartState=((WebflowState)parent).getStartState();
setAttribute("id",id);
if (!id.equals(oldId) && parent instanceof WebflowState) {
if (this.equals(oldStartState)) {
((WebflowState)parent).setStartState(this);
}
}
if (this.inputTransitions != null && this.inputTransitions.size() > 0) {
for (    ITransition trans : this.inputTransitions) {
trans.setToState(this);
}
}
}
}
public class Test {
/**
* Setter for the id of the referenced site
* @param id the id
* @throws UnsupportedOperationException in case this configuration is {@link #readonly}
* @throws IllegalArgumentException in case the parsed ID is <code>null</code> or an empty String
* @see #getId()
*/
public final void setId(String id) throws UnsupportedOperationException, IllegalArgumentException {
if (id == null) {
throw new IllegalArgumentException("The ID of the Site MUST NOT be set to NULL!");
}
else   if (id.isEmpty()) {
throw new IllegalArgumentException("The ID of the Site MIST NOT be set to an empty String!");
}
else {
config.put(ID,id);
}
}
}
public class Test {
@Override public void setId(int id){
try {
final Object obj2=obj;
final int val2=id;
AccessController.doPrivileged(new PrivilegedExceptionAction<Object>(){
@Override public Object run() throws NoSuchFieldException, IllegalAccessException {
Field f=obj2.getClass().getField("id");
f.setInt(obj2,val2);
return null;
}
}
);
}
catch (  PrivilegedActionException e) {
throw new ObjectDBError("Class " + obj.getClass() + " does not have a unique 'id' property. Please add one.");
}
}
}
public class Test {
/**
* {@inheritDoc}
*/
public void setId(Object id) throws IllegalArgumentException {
if (id instanceof String) {
this.id=new GroupId(id);
}
else   if (id instanceof GroupId) {
this.id=(GroupId)id;
}
else   if (id instanceof Map) {
this.id=new GroupId(((Map)id).get("value"));
}
else {
throw new IllegalArgumentException("The provided GroupId is not valid");
}
}
}
public class Test {
public void setId(int parameterIndex,ObjectId... id){
if (id == null || id.length == 0) {
throw new IllegalArgumentException("Id must be set!");
}
StringBuilder sb=new StringBuilder();
for (  ObjectId oid : id) {
if (oid == null || oid.getId() == null) {
throw new IllegalArgumentException("Id is null!");
}
if (sb.length() > 0) {
sb.append(",");
}
sb.append(escape(oid.getId()));
}
parametersMap.put(parameterIndex,sb.toString());
}
}
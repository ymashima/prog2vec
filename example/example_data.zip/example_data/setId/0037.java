public class Test {
public static void setId(Object o,String id){
try {
Field f=findDeclaredField(o.getClass(),"id");
if (f != null) {
f.set(o,id);
return;
}
Method m=findSetterMethod(o.getClass(),"id");
if (m != null) {
m.invoke(o,id);
}
}
catch (  Exception e) {
throw wrap(e);
}
}
}
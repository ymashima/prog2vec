public class Test {
/**
* Sets Primary Key (Row key) into entity field that was annotated with @Id.
* @param entity the entity
* @param metadata the metadata
* @param rowKey the row key
* @throws PropertyAccessException the property access exception
*/
public static void setId(Object entity,EntityMetadata metadata,Object rowKey){
try {
Field idField=(Field)metadata.getIdAttribute().getJavaMember();
set(entity,idField,rowKey);
}
catch (  IllegalArgumentException iarg) {
throw new PropertyAccessException(iarg);
}
}
}
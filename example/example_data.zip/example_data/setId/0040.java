public class Test {
/**
* Sets the id property of the feature. This method also allows wiping the current id by setting the name of the id to null. The value will in that case be ignored.
* @param name the name of the id property, or null if the geometry property is to be wiped
* @param value the value of the id property of this feature
*/
public void setId(String name,Object value){
if (name == null) {
idPropertyName=null;
idValue=null;
}
else {
idPropertyName=name;
idValue=value;
}
}
}
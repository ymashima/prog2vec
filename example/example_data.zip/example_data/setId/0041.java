public class Test {
/**
* Sets the ID to display. If ID = 0, nothing is displayed.
* @param id
*/
public void setId(long id){
if (id == 0) {
uiDisplayPanel.setVisible(false);
}
else {
uiDisplayPanel.setVisible(true);
uiLabel.setText("File ID: " + id);
}
invalidate();
repaint();
}
}
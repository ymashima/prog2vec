public class Test {
/**
* Set the identifier and convert it if necessary.
* @param id
*/
public void setId(final Object id){
if (id != null) {
String sId=id.toString();
final String type=this.getClass().getSimpleName();
if (type != null && sId.startsWith(type + SEPARATOR)) {
sId=sId.substring(type.length() + SEPARATOR.length());
}
logger.debug("identifier : {}",sId);
this.id=sId;
}
}
}
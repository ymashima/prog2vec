public class Test {
/**
* THIS METHOD IS NOT PART OF THE WICKET PUBLIC API. DO NOT USE IT! Sets the id of this component.
* @param id The non-null id of this component
*/
final void setId(final String id){
if (!(this instanceof Page)) {
if (Strings.isEmpty(id)) {
throw new WicketRuntimeException("Null or empty component ID's are not allowed.");
}
}
if ((id != null) && (id.indexOf(':') != -1 || id.indexOf('~') != -1)) {
throw new WicketRuntimeException("The component ID must not contain ':' or '~' chars.");
}
this.id=id;
}
}
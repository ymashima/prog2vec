public class Test {
public void setId(String id) throws FormatException, IOException {
if (id.equals(currentId))   return;
close();
currentId=id;
out=new RandomAccessOutputStream(currentId);
MetadataRetrieve r=getMetadataRetrieve();
initialized=new boolean[r.getImageCount()][];
int oldSeries=series;
for (int i=0; i < r.getImageCount(); i++) {
setSeries(i);
initialized[i]=new boolean[getPlaneCount()];
}
setSeries(oldSeries);
}
}
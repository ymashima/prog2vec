public class Test {
/**
* Set this modelObject's ID in the given Graphiti context.
* @param context - if this is a IPictogramElementContext, set the propertyin the contained PictogramElement's list of properties; otherwise set the Context's property
* @param id - ID of this Custom Task
*/
public static void setId(IContext context,String id){
if (context instanceof IPictogramElementContext) {
PictogramElement pe=((IPictogramElementContext)context).getPictogramElement();
Graphiti.getPeService().setPropertyValue(pe,CUSTOM_TASK_ID,id);
}
else {
context.putProperty(CUSTOM_TASK_ID,id);
}
}
}
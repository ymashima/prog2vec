public class Test {
/**
* @param id Cannot have a space in the value
* @param depth
* @param rowNumber
*/
public void setId(String id,int depth,int rowNumber){
id=id.trim();
if (id.indexOf(" ") >= 0) {
throw new IllegalArgumentException("You cannot have a space in an id [" + id + "]");
}
this.id=id;
this.depth=depth;
this.rowNumber=rowNumber;
}
}
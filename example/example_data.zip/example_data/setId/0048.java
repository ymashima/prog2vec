public class Test {
public Builder setId(org.apache.hadoop.hdfs.protocol.proto.HdfsProtos.DatanodeIDProto value){
if (idBuilder_ == null) {
if (value == null) {
throw new NullPointerException();
}
id_=value;
onChanged();
}
else {
idBuilder_.setMessage(value);
}
bitField0_|=0x00000001;
return this;
}
}
public class Test {
/**
* Overrides the superclass method to also set the  {@link #getRealId() realId} property.
*/
@Override public void setId(String id){
parseRealId(id);
if ((this.id != null) && (manager != null)) {
manager.remove(this);
}
this.id=id;
this.clusterStatus=new ClusteredSessionManagementStatus(this.realId,true,null,null);
if (manager != null) {
manager.add(this);
}
}
}
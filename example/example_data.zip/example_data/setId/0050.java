public class Test {
private void setId(SNode node,SNodeId id){
SModel model=SNodeOperations.getModel(node);
if (SNodeOperations.getParent(node) == null) {
SNodeOperations.detachNode(node);
node.setId(id);
SModelOperations.addRootNode(model,node);
}
else {
SNode stubNode=new SNode(model,"jetbrains.mps.lang.core.structure.BaseConcept");
SNodeOperations.replaceWithAnother(node,stubNode);
node.setId(id);
SNodeOperations.replaceWithAnother(stubNode,node);
}
}
}
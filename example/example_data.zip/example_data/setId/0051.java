public class Test {
public Builder setId(org.onebusaway.transit_data_federation.services.service_alerts.ServiceAlerts.Id value){
if (idBuilder_ == null) {
if (value == null) {
throw new NullPointerException();
}
id_=value;
onChanged();
}
else {
idBuilder_.setMessage(value);
}
bitField0_|=0x00000001;
return this;
}
}
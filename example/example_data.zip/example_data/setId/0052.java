public class Test {
public void setId(int id){
_id=id;
if (StateUtils.isOracle(_id)) {
_territoryBottomLeftPoint=new Point(0,0);
_territoryTopRightPoint=_territoryBottomLeftPoint;
}
else {
_territoryBottomLeftPoint=MapUtils.getTerritoryBottomLeftPoint(_id);
_territoryTopRightPoint=MapUtils.getTerritoryTopRightPoint(_id);
}
_territoryCenter=new Point((_territoryBottomLeftPoint.x + _territoryTopRightPoint.x) / 2,(_territoryBottomLeftPoint.y + _territoryTopRightPoint.y) / 2);
System.out.println("Ant[" + _id + "] territory: bottom-left:"+ _territoryBottomLeftPoint+ ", top-right:"+ _territoryTopRightPoint+ ", center:"+ _territoryCenter);
}
}
public class Test {
public void setId(String id) throws FormatException, IOException {
if (id.equals(currentId))   return;
super.setId(id);
if (imageLocations == null) {
MetadataRetrieve r=getMetadataRetrieve();
imageLocations=new String[r.getImageCount()][];
for (int i=0; i < imageLocations.length; i++) {
setSeries(i);
imageLocations[i]=new String[planeCount()];
}
setSeries(0);
}
}
}
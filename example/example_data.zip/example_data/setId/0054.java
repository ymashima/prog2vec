public class Test {
/**
* Changes the identifier of this value.
* @param id the new id, must not be <code>null</code>
*/
public void setId(String id){
if (id == null)   throw new IllegalArgumentException("id must not be null");
this.id=id;
if (this.manager != null) {
U me=me();
this.manager.remove(me);
this.manager.add(id,kind,me);
}
}
}
public class Test {
/**
* Sets the unique id for this item which must be non-null and cannot contain any commas or dots.
* @param newId
*/
public void setId(String newId){
if (newId == null || newId.contains(",") || newId.contains(" ")) {
throw new IllegalArgumentException("Invalid item id");
}
if (this.id != null && !this.id.equals(newId)) {
throw new IllegalStateException("id may not be changed");
}
this.id=newId;
}
}
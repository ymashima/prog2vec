public class Test {
/**
* Auto generated setter method
* @param param Id
*/
public void setId(long param){
if (param == java.lang.Long.MIN_VALUE) {
localIdTracker=true;
}
else {
localIdTracker=true;
}
this.localId=param;
}
}
public class Test {
/**
* _more_
* @param newId
*/
public void setId(String newId){
if (!id.equals("")) {
idToGlyph.remove(id);
}
id=newId;
if (!id.equals("")) {
idToGlyph.put(id,this);
}
}
}
public class Test {
/**
* @param id the id of the person (XCN.1 and XCN.9).
*/
public void setId(Identifiable id){
if (id != null) {
setValue(getHapiObject().getXcn1_IDNumber(),id.getId());
setAssigningAuthority(id.getAssigningAuthority(),getHapiObject().getXcn9_AssigningAuthority());
}
else {
getHapiObject().getXcn1_IDNumber().clear();
getHapiObject().getXcn9_AssigningAuthority().clear();
}
}
}
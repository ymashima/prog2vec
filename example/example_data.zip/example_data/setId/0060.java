public class Test {
/**
* Set (update) the SHA-1 of this entry. Invalidates the id's of all entries above this entry as they will have to be recomputed.
* @param n SHA-1 for this entry.
*/
public void setId(final ObjectId n){
final Tree p=getParent();
if (p != null && id != n) {
if ((id == null && n != null) || (id != null && n == null) || !id.equals(n)) {
p.setId(null);
}
}
id=n;
}
}
public class Test {
/**
* Sets the task id as a private task parameter.
* @param task a scheduled task
* @param id   task id
*/
public static void setId(final ScheduledTask<?> task,final String id){
if (id == null || id.trim().length() == 0) {
task.getTaskParams().remove(NexusTask.ID_KEY);
}
else {
task.getTaskParams().put(NexusTask.ID_KEY,id);
}
}
}
public class Test {
/**
* Sets the task id as a private task parameter.
* @param task a nexus task
* @param id   task id
*/
public static void setId(final SchedulerTask<?> task,final String id){
if (id == null || id.trim().length() == 0) {
task.getParameters().remove(NexusTask.ID_KEY);
}
else {
task.addParameter(NexusTask.ID_KEY,id);
}
}
}
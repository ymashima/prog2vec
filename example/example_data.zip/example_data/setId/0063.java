public class Test {
/**
* Sets the <code>Id</code> attribute
* @param Id ID
*/
public void setId(String id){
if (id != null) {
this.constructionElement.setAttributeNS(null,Constants._ATT_ID,id);
this.constructionElement.setIdAttributeNS(null,Constants._ATT_ID,true);
}
else {
this.constructionElement.removeAttributeNS(null,Constants._ATT_ID);
}
}
}
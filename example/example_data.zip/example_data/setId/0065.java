public class Test {
/**
* Set the block ID.
* @param id block id (between 0 and {@link #MAX_ID}).
*/
public void setId(int id){
if (id > MAX_ID) {
throw new IllegalArgumentException("Can't have a block ID above " + MAX_ID + " ("+ id+ " given)");
}
if (id < 0) {
throw new IllegalArgumentException("Can't have a block ID below 0");
}
this.id=(short)id;
}
}
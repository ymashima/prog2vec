public class Test {
/**
* Sets the identifier of the repository.
* @param id The identifier of the repository, may be {@code null}.
* @return This builder for chaining, never {@code null}.
*/
public Builder setId(String id){
this.id=(id != null) ? id : "";
if (prototype != null) {
delta(ID,this.id,prototype.getId());
}
return this;
}
}
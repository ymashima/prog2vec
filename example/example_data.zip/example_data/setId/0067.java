public class Test {
/**
* Sets the XML element id attribute.
* @param id string representing the element id.
* @throws IllegalArgumentException if the id is not valid.
*/
public void setId(String id) throws XMLException {
if (id != null && "".equals(id.trim()))   throw new XMLException("Empty id String");
if (!validate(id))   throw new XMLException("Invalid identifier: " + id);
String aux=this.id;
this.id=id;
notifyAltered(NCLElementAttributes.ID,aux,id);
}
}
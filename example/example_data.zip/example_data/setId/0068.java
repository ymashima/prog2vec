public class Test {
@Override public void setId(String value){
if (otherwise != null) {
otherwise.setId(value);
}
else   if (!getWhenClauses().isEmpty()) {
int size=getWhenClauses().size();
getWhenClauses().get(size - 1).setId(value);
}
else {
super.setId(value);
}
}
}
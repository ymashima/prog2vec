public class Test {
/**
* {@inheritDoc}
* @see net.certware.argument.aml.parts.DiscoveryMethodPropertiesEditionPart#setId(String newValue)
*/
public void setId(String newValue){
if (newValue != null) {
id.setText(newValue);
}
else {
id.setText("");
}
}
}
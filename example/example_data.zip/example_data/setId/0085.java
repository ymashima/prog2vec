public class Test {
/**
* 设置主键ID，
* @param id
*/
public void setId(String id){
if (StringUtils.isEmpty(id)) {
this.id=null;
}
else {
this.id=id;
}
}
}
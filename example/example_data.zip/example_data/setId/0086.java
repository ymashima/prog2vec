public class Test {
private void setId(CatalogInfo info,Class<? extends CatalogInfo> type){
final String curId=info.getId();
final String id;
if (null != curId) {
id=curId;
}
else {
String newId=UUID.randomUUID().toString();
id=type.getSimpleName() + "." + newId;
}
OwsUtils.set(info,"id",id);
}
}
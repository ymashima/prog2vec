public class Test {
/**
* A wrapper for setting vertex Id's which supports multiple vertex owners.
* @param v Vertex which the caller intends to set its Id.
* @return The Id.
*/
protected void setId(VertexType v,int id){
if (subgraphIndex != 0) {
v.setSubgraphId(subgraphIndex,id);
return;
}
v.setId(id);
}
}
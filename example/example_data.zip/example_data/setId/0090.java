public class Test {
/**
* {@inheritDoc}
* @see org.obeonetwork.graal.parts.TasksGroupPropertiesEditionPart#setId(String newValue)
*/
public void setId(String newValue){
if (newValue != null) {
id.setText(newValue);
}
else {
id.setText("");
}
}
}
public class Test {
@Override public void setId(String id){
if (BridgeUtil.isPortletRequest()) {
if (null == id) {
id=createUniqueId();
}
if (!id.startsWith(NAMESPACE_PREFIX)) {
ExternalContext ec=FacesContext.getCurrentInstance().getExternalContext();
id=NAMESPACE_PREFIX + ec.encodeNamespace("") + "_"+ id;
}
}
super.setId(id);
}
}
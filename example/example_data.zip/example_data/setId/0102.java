public class Test {
public void setId(TId node){
if (_id_ != null) {
_id_.parent(null);
}
if (node != null) {
if (node.parent() != null) {
node.parent().removeChild(node);
}
node.parent(this);
}
_id_=node;
}
}
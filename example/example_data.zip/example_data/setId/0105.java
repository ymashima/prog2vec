public class Test {
/**
* Mutator for certId attribute
* @param str new value for certId attribute
* @throws DigiDocException for validation errors
*/
public void setId(String str) throws DigiDocException {
if (signature != null && signature.getSignedDoc() != null && !signature.getSignedDoc().getVersion().equals(SignedDoc.VERSION_1_3) && !signature.getSignedDoc().getVersion().equals(SignedDoc.VERSION_1_4)) {
DigiDocException ex=validateId(str);
if (ex != null)     throw ex;
}
id=str;
}
}
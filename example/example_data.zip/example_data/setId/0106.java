public class Test {
/**
* Mutator for Id attribute
* @param str new value for Id attribute
* @throws DigiDocException for validation errors
*/
public void setId(String str) throws DigiDocException {
DigiDocException ex=validateId(str);
if (ex != null) {
throw ex;
}
id=str;
}
}
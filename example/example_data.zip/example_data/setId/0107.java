public class Test {
/**
* Sets the id for the context definition that will be created by this builder.
* @param id the id to set
*/
public void setId(String id){
if (id != null) {
if (StringUtils.isBlank(id)) {
throw new IllegalArgumentException("context id is blank");
}
}
this.id=id;
}
}
public class Test {
/**
* Set the Id. <p/> Allows you to manully create a header This will modify the databuffer accordingly
* @param length
*/
public void setId(int length){
byte[] headerSize=Utils.getSizeBEInt32(length);
dataBuffer.put(5,headerSize[0]);
dataBuffer.put(6,headerSize[1]);
dataBuffer.put(7,headerSize[2]);
dataBuffer.put(8,headerSize[3]);
this.length=length;
}
}
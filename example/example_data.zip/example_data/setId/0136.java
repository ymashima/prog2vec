public class Test {
/**
* Sets Id of Identity
* @param id
*/
public void setId(String id){
if (id != null) {
this.put(Field.ID.toString(),id);
}
else {
this.put(Field.ID.toString(),"");
}
}
}
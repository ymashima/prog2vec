public class Test {
/**
* @param id the id to set
*/
public void setId(String id){
this.id=id;
if (licenseInfoNode != null) {
Property p=model.getProperty(SpdxRdfConstants.SPDX_NAMESPACE,SpdxRdfConstants.PROP_LICENSE_ID);
model.removeAll(resource,p,null);
p=model.createProperty(SpdxRdfConstants.SPDX_NAMESPACE,SpdxRdfConstants.PROP_LICENSE_ID);
resource.addProperty(p,id);
}
}
}
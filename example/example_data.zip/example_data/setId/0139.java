public class Test {
public synchronized void setId(int id){
userId=id;
try {
FileWriter writer=new FileWriter(this.getUserIdFile());
writer.write(Integer.toString(userId));
writer.close();
}
catch (  IOException io) {
logger.error("Error writing the user id file",io);
throw new RuntimeException(io);
}
}
}
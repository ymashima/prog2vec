public class Test {
/**
* Setter for the ID of the yard. The id is usually a sort name such as "dbpedia", "freebase", "geonames.org", "my.projects" ...<p> If  {@link #isMultiYardIndexLayout()} than this ID is used to identifyRepresentations of this Yard within the SolrIndex.
* @param the id of the yard. Required, not null, not empty!
*/
public final void setId(String id){
if (id != null) {
config.put(Yard.ID,id);
}
else {
config.remove(Yard.ID);
}
}
}
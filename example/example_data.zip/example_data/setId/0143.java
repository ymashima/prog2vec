public class Test {
/**
* Sets the id.
* @param id id or <code>null</code> to reset
*/
public void setId(Id id){
if (id == null) {
removeExtension(Id.class);
}
else {
setExtension(id);
}
}
}
public class Test {
/**
* affecte la clef primaire de l'objet
* @param id The new Id value
* @throws IllegalArgumentException TODO
*/
public void setId(Object id){
if (id == null || data.getId() != null) {
throw new IllegalArgumentException();
}
data.setId(id);
}
}
public class Test {
public void setId(String id) throws CoreException {
ensureModelEditable();
IBundle bundle=getBundle();
if (bundle != null) {
String old=getId();
IManifestHeader header=bundle.getManifestHeader(Constants.BUNDLE_SYMBOLICNAME);
if (header instanceof BundleSymbolicNameHeader)     ((BundleSymbolicNameHeader)header).setId(id);
else     bundle.setHeader(Constants.BUNDLE_SYMBOLICNAME,id);
model.fireModelObjectChanged(this,IIdentifiable.P_ID,old,id);
}
}
}
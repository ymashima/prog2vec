public class Test {
/**
* Will set the id property on the document IF a mutator exists. Otherwise nothing happens.
* @param document
* @param id
*/
public static void setId(Object document,String id){
DocumentAccessor d=getAccessor(document);
if (d.hasIdMutator()) {
d.setId(document,id);
}
}
}
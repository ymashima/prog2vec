public class Test {
public void setId(Object id){
if (id instanceof Id) {
this.id=(Id)id;
}
else   if (id != null) {
this.id=getIdManager().getId(id.toString());
}
else {
this.id=null;
}
}
}
public class Test {
/**
* Set the accession number of the entry
* @param v The accession number
*/
public void setId(String id) throws DataError {
Matcher matcher=GO_ID_PATTERN.matcher(id);
if (!matcher.matches()) {
throw new DataError("GO id doesn't look right '" + id + "'");
}
this.id=matcher.group(1);
}
}
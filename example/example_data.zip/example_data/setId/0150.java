public class Test {
public void setId(Key parentKey,String id){
if (parentKey == null) {
return;
}
if (id != null) {
setId(id);
}
else {
key=KeyFactory.createKey(parentKey,WalletItemData.class.getName(),null);
}
}
}
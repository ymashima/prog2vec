public class Test {
public Builder setId(org.apache.hadoop.hdfs.protocol.proto.HdfsProtos.DatanodeIDProto.Builder builderForValue){
if (idBuilder_ == null) {
id_=builderForValue.build();
onChanged();
}
else {
idBuilder_.setMessage(builderForValue.build());
}
bitField0_|=0x00000001;
return this;
}
}
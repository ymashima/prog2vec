public class Test {
/**
* @throws IllegalArgumentException {@inheritDoc}
* @throws IllegalStateException    {@inheritDoc}
*/
public void setId(String id){
if (this.id == null || !(this.id.equals(id))) {
validateId(id);
this.id=id;
}
this.clientId=null;
}
}
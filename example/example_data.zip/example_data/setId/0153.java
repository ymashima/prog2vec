public class Test {
/**
* <p>Set the component identifier for our component.  If the argument begins with  {@link UIViewRoot#UNIQUE_ID_PREFIX} throw an<code>IllegalArgumentException</code></p>
* @param id The new component identifier.  This may not start with{@link UIViewRoot#UNIQUE_ID_PREFIX}.
* @throws IllegalArgumentException if the argument isnon-<code>null</code> and starts with  {@link UIViewRoot#UNIQUE_ID_PREFIX}.
*/
public void setId(String id){
if (null != id && id.startsWith(UIViewRoot.UNIQUE_ID_PREFIX)) {
throw new IllegalArgumentException();
}
this.id=id;
}
}
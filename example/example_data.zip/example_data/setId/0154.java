public class Test {
/**
* Set the files identifier.
* @param id A 40-character identifier.
* @throws IllegalArgumentException If the given id is invalid.
*/
public void setId(String id){
if (id == null || id.length() != 40 || !Hex.isHex(id)) {
throw new IllegalArgumentException("Expecting a 40-character hex string.");
}
this.id=id;
}
}
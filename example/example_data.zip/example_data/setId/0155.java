public class Test {
/**
* Set the media identifier.
* @param id A 32-character identifier.
* @throws IllegalArgumentException If the given id is invalid.
*/
public void setId(String id){
if (id == null || id.length() != 32 || !Hex.isHex(id)) {
throw new IllegalArgumentException("Expecting a 32-character hex string.");
}
this.id=id;
}
}
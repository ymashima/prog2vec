public class Test {
/**
* sets the id of the feed, this is not intended for users to use. When creating a new datastream to submit to pachube, Pachube will provide a Unique id. THIS METHOD SHOULD ONLY BE USED BY THE PachubeFactory.
* @param id
*/
public void setId(String id){
try {
this.id=Integer.parseInt(id);
}
catch (  Exception e) {
}
}
}
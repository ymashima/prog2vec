public class Test {
/**
* Sets the value of the id on this builder to the given value.
* @param actionId the actionId value to set, must no tbe null or blank
* @throws IllegalArgumentException if the actionId is non-null and blank
*/
public void setId(String actionId){
if (actionId != null && StringUtils.isBlank(actionId)) {
throw new IllegalArgumentException("action ID must be null or non-blank");
}
this.id=actionId;
}
}
public class Test {
/**
* Sets the value of the id on this builder to the given value.
* @param id the id value to set, must be null or non-blank
* @throws IllegalArgumentException if the id is non-null and blank
*/
public void setId(String id){
if (null != id && StringUtils.isBlank(id)) {
throw new IllegalArgumentException("id must be null or non-blank");
}
this.id=id;
}
}
public class Test {
/**
* Sets the value of the propId on this builder to the given value.
* @param propId the propId value to set
* @throws IllegalArgumentException if the propId is null or blank
*/
public void setId(String propId){
if (propId != null && StringUtils.isBlank(propId)) {
throw new IllegalArgumentException("proposition id must not be blank");
}
this.id=propId;
}
}
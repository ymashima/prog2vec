public class Test {
/**
* Sets the value of the id on this builder to the given value.
* @param id the id value to set, must not be null or blank
* @throws IllegalArgumentException if the id is null or blank
*/
public void setId(String id){
if (id != null && StringUtils.isBlank(id)) {
throw new IllegalArgumentException("id must not be null or blank");
}
this.id=id;
}
}
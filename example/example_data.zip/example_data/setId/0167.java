public class Test {
/**
* Sets the value of the id on this builder to the given value.
* @param ruleId the id value to set, must not be null or blank
* @throws IllegalArgumentException if the id is null or blank
*/
public void setId(String ruleId){
if (ruleId != null && StringUtils.isBlank(ruleId)) {
throw new IllegalArgumentException("rule ID must be null or else non-blank");
}
this.id=ruleId;
}
}
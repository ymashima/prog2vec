public class Test {
/**
* Sets the value of the ' {@link org.eclipselabs.mongo.emf.query.simple.junit.model.Location#getId <em>Id</em>}' attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
* @param value the new value of the '<em>Id</em>' attribute.
* @see #getId()
* @generated
*/
public void setId(Object newId){
Object oldId=id;
id=newId;
if (eNotificationRequired())   eNotify(new ENotificationImpl(this,Notification.SET,ModelPackage.LOCATION__ID,oldId,id));
}
}
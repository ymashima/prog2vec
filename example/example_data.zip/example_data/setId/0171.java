public class Test {
/**
* <!-- begin-user-doc --> <!-- end-user-doc -->
* @generated
*/
@Override public void setId(String newId){
String oldId=id;
id=newId;
if (eNotificationRequired()) {
eNotify(new ENotificationImpl(this,Notification.SET,WorkflowPackage.STATE__ID,oldId,id));
}
}
}
public class Test {
public Builder setId(org.onebusaway.transit_data_federation.services.service_alerts.ServiceAlerts.Id.Builder builderForValue){
if (idBuilder_ == null) {
id_=builderForValue.build();
onChanged();
}
else {
idBuilder_.setMessage(builderForValue.build());
}
bitField0_|=0x00000001;
return this;
}
}
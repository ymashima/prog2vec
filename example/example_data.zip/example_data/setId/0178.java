public class Test {
static void setId(Object obj,int id) throws Exception {
Field f=null;
if (obj instanceof Property) {
f=Property.class.getDeclaredField("id");
}
else {
f=obj.getClass().getDeclaredField("id");
}
f.setAccessible(true);
f.setInt(obj,id);
}
}
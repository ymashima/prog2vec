public class Test {
/**
* Method declaration
* @param newId
* @see
*/
public void setId(String newId){
id=newId;
if (id == null) {
id="newFormLine";
}
}
}
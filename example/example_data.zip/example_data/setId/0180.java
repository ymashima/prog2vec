public class Test {
/**
* Set the id of this prototype
* @param id the new id
* @throws IllegalStateException if id has already been set
*/
public void setId(String id){
if (this.id != null) {
throw new IllegalStateException("id is already set");
}
this.id=id;
}
}
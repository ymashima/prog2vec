public class Test {
/**
* <!-- begin-user-doc --> <!-- end-user-doc -->
* @generated
*/
public void setId(String newId){
String oldId=id;
id=newId;
boolean oldId_set_=id_set_;
id_set_=true;
if (isNotifying())   notify(ChangeKind.SET,INTERNAL_ID,oldId,id,!oldId_set_);
}
}
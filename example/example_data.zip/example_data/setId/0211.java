public class Test {
/**
* @param id the id to set
*/
public void setId(String id){
if (StringUtils.hasText(id)) {
this.id=id;
}
else {
this.id=null;
}
}
}
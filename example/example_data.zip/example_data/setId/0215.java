public class Test {
/**
* Set error id
* @param id error id
* @throws NullPointerException if the supplied id is <b>null</b>
*/
public void setId(ErrorId id){
if (id == null) {
throw new NullPointerException("The supplied Id must not be null");
}
m_id=id;
}
}
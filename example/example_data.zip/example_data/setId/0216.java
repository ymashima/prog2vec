public class Test {
public void setId(Integer value){
if (value == null)   return;
if (!value.equals(myInstance().id())) {
if (!myInstance().application().isIDInUse(value)) {
myInstance().setId(value);
}
else {
mySession().addErrorIfAbsent("This ID is in use");
}
}
}
}
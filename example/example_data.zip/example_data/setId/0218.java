public class Test {
private void setId(String id){
if (id == null || id.length() == 0) {
throw new IllegalArgumentException("PubMedId may not be null or empty.");
}
Matcher matcher=s_onlyDigits.matcher(id);
if (!matcher.matches()) {
throw new IllegalArgumentException("Only digits are valid in a PubMedId, and it may not start with 0.");
}
d_id=id;
}
}
public class Test {
/**
* <p> Sets the id of the target platform location. </p>
* @param id the id of the target platform location.
*/
public void setId(String id){
if (isReference()) {
throw tooManyAttributes();
}
this._id=id;
}
}
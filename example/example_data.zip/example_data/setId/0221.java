public class Test {
public void setId(String id) throws FormatException, IOException {
super.setId(id);
lastImage=null;
lastImageIndex=-1;
lastImageSeries=-1;
lastImageX=-1;
lastImageY=-1;
lastImageWidth=-1;
lastImageHeight=-1;
}
}
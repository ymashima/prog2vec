public class Test {
/**
* @see UIComponentBase#setId(java.lang.String)
*/
@Override public void setId(String id){
if (Character.isDigit(id.charAt(0))) {
id="id" + id;
}
setMarkupAttribute("id",id);
super.setId(id);
}
}
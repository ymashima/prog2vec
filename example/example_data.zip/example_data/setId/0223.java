public class Test {
/**
* Set the ID for the Content Specification Topic.
* @param id The Content Specification Topic ID.
*/
public void setId(final String id){
if (id.matches(CSConstants.EXISTING_TOPIC_ID_REGEX)) {
DBId=Integer.parseInt(id);
}
this.id=id;
}
}
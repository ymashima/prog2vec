public class Test {
/**
* Set a new item identifier
* @param newId item identifier
* @exception RemoteException if an error occurs
* @since 1.0
*/
public void setId(Integer newId) throws RemoteException {
id=newId;
isDirty=true;
}
}
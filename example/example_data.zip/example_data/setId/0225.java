public class Test {
/**
* Sets the id of this context. <p> This is a framework-only method that exists solely so that context types can be contributed via an extension point and that should not be called in client code; use  {@link #TemplateContextType(String)} instead.</p>
* @param id the identifier of this context
* @throws RuntimeException an unspecified exception if the id has alreadybeen set on this context type
*/
public final void setId(String id) throws RuntimeException {
Assert.isNotNull(id);
Assert.isTrue(fId == null);
fId=id;
}
}
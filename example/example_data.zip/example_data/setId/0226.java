public class Test {
@JsonProperty("_id") public void setId(String s){
Assert.hasText(s,"id must have a value");
if (id != null && id.equals(s)) {
return;
}
if (id != null) {
throw new IllegalStateException("cannot set id, id already set");
}
id=s;
}
}
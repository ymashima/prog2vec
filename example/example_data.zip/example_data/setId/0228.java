public class Test {
public void setId(String id){
if (id == null) {
throw new IllegalArgumentException("id",new NullPointerException("id"));
}
id=id.trim();
if (!defaultPorts.containsKey(id)) {
throw new IllegalArgumentException("id: " + id);
}
this.id=id;
}
}
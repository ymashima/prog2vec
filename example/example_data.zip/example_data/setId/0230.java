public class Test {
public void setId(String id){
if (autoRegistered && getProject().getReference(this.id) == this) {
getProject().getReferences().remove(this.id);
autoRegistered=false;
}
this.id=id;
if (getProject() != null) {
getProject().addReference(this.id,this);
}
}
}
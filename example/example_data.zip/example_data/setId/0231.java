public class Test {
/**
* * Sets the Id of the contact the e-mail address represents. When Id is specified, Address should be set to null.
* @param id the new id
*/
public void setId(ItemId id){
if (this.canSetFieldValue(this.id,id)) {
this.id=id;
this.changed();
}
}
}
public class Test {
/**
* Mutator for id attribute
* @param str new value for id attribute
* @throws DigiDocException for validation errors
*/
public void setId(String str) throws DigiDocException {
DigiDocException ex=validateId(str,false);
if (ex != null)   throw ex;
id=str;
}
}
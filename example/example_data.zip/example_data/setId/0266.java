public class Test {
public void setId(Long id){
if (this.id != null) {
throw new IllegalStateException(this + " id cannot be changed");
}
this.getChanged().record("id",this.id,id);
this.id=id;
if (UoW.isOpen()) {
UoW.getIdentityMap().store(this);
}
}
}
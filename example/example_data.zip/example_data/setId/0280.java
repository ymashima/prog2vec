public class Test {
/**
* @param id the id to set.  Should be null to build {@link TermDefinition}s for creation operations.
* @throws IllegalArgumentException if the id is non-null and only contains whitespace
*/
public void setId(String id){
if (id != null && StringUtils.isBlank(id)) {
throw new IllegalArgumentException("id must contain non-whitespace chars");
}
this.id=id;
}
}
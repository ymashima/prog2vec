public class Test {
/**
* @param id the id to set.  for {@link TermParameterDefinition}s used in creational  service methods, it must be null.  Otherwise, it must be non-null and contain non-whitespace chars.
* @throws IllegalArgumentException if id is all whitespace chars
*/
public void setId(String id){
if (id != null && StringUtils.isBlank(id)) {
throw new IllegalArgumentException("id must contain non-whitespace chars");
}
this.id=id;
}
}
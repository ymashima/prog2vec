public class Test {
/**
* Sets the ID of this component. The framework calls this method automatically. It should never be called by plugin code.
* @param id the new ID for the component
*/
public void setId(String id){
if (id != null && initializer != null && initializer.isInitialized()) {
throw new IllegalStateException("id must be set before component is initialized");
}
this.id=id;
}
}
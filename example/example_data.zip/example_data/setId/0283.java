public class Test {
/**
* Set the id for this atom.
*/
public void setId(int newId){
if (newId == Undefined) {
System.out.println("explicitly setting id to undefined " + this);
System.out.println("(anti-desirable)");
}
id=newId;
}
}
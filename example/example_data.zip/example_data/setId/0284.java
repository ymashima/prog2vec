public class Test {
/**
* @param id
* @see http://java.sun.com/javaee/5/docs/api/javax/faces/webapp/UIComponentTagBase.html#setId(java.lang.String)
*/
@Override public void setId(String id){
if (id != null && id.startsWith(UIViewRoot.UNIQUE_ID_PREFIX)) {
throw new IllegalArgumentException("Id is non-null and starts with UIViewRoot.UNIQUE_ID_PREFIX: " + id);
}
_id=id;
}
}
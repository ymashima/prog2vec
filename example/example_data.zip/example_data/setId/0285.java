public class Test {
public void setId(List<TId> list){
this._id_.clear();
this._id_.addAll(list);
for (  TId e : list) {
if (e.parent() != null) {
e.parent().removeChild(e);
}
e.parent(this);
}
}
}
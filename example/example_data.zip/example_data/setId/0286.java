public class Test {
/**
* @see org.opencms.gwt.client.ui.I_CmsListItem#setId(java.lang.String)
*/
public void setId(String id){
CmsList<CmsListItem> parentList=getParentList();
if (parentList != null) {
parentList.changeId(this,id);
}
m_id=id;
}
}
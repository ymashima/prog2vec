public class Test {
/**
* Sets the ID to display. If ID = 0, nothing is displayed.
* @param id
*/
void setId(long id){
this.id=id;
if (currentDisplay != null && currentDisplay instanceof FieldParamEditor) {
((FieldParamEditor)currentDisplay).setId(id);
}
}
}
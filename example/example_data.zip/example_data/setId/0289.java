public class Test {
/**
* Set the id of the npc
* @param npcId
*/
public final void setId(String npcId){
if (npcId == null) {
throw new NullPointerException("NPC id cannot be null in npc line");
}
this.id=npcId;
}
}
public class Test {
/**
* Sets the <code>Id</code> attribute
* @param Id <code>Id</code> attribute
*/
public void setId(String Id){
if (Id != null) {
this.constructionElement.setAttributeNS(null,Constants._ATT_ID,Id);
this.constructionElement.setIdAttributeNS(null,Constants._ATT_ID,true);
}
}
}
public class Test {
/**
* Sets the <code>Id</code> attribute of this <code>Reference</code> element
* @param id the <code>Id</code> attribute of this <code>Reference</code> element
*/
public void setId(String id){
if (id != null) {
this.constructionElement.setAttributeNS(null,Constants._ATT_ID,id);
this.constructionElement.setIdAttributeNS(null,Constants._ATT_ID,true);
}
}
}
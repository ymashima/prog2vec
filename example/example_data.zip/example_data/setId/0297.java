public class Test {
@Override public void setId(String id){
if (SemanticType.validate(id)) {
SemanticType st=new SemanticType(id);
_namespace=Thinklab.get().getNamespace(st.getConceptSpace());
_id=st.getLocalName();
}
else {
_id=id;
}
}
}
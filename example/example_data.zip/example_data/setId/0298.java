public class Test {
/**
* Set the id. In most cases, this is provided by the constructor or through the beanId provided in the applicationContext.
* @param id
*/
protected void setId(String id){
if (!StringUtils.hasText(id)) {
id=null;
}
this.id=id;
}
}
public class Test {
/**
* Sets the issue ID.
* @param id issue ID or <code>null</code> to remove this parameter if set.
*/
public void setId(Integer id){
if (this.id == null ? id != null : !this.id.equals(id)) {
this.id=id;
setStringCustomParameter("id",id == null ? null : id.toString());
}
}
}
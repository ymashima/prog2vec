public class Test {
/**
* Convenience method, sets ID value on this model, equivalent to <code>set(getIdName(), id)</code>.
* @param id value of ID
* @return reference to self for chaining.
*/
public <T extends Model>T setId(Object id){
set(getIdName(),id);
return (T)this;
}
}
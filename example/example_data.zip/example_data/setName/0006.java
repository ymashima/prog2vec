public class Test {
@Override public void setName(String newName) throws InvalidNameException {
if (!isDeserializing() && (newName == null || !DMRegExp.ENTITY_NAME_PATTERN.matcher(newName).matches())) {
throw new InvalidNameException();
}
if ((name == null) || (!name.equals(newName))) {
DMRepository containerRepository=getRepository();
if (!isDeserializing()) {
if (containerRepository != null) {
containerRepository.unregisterEntity(this,false);
}
}
String oldName=name;
if (!isDeserializing() && _eoEntity != null) {
try {
_eoEntity.setName(newName);
name=newName;
}
catch (      IllegalStateException e) {
throw new DuplicateNameException(newName);
}
finally {
if (!isDeserializing()) {
if (containerRepository != null) {
containerRepository.registerEntity(this);
}
}
}
}
setChanged();
notifyObservers(new DMEntityNameChanged(this,oldName,newName));
if (!isDeserializing() && getEOEntity() != null) {
Iterator<EORelationship> i=getEOEntity().getIncomingRelationships().iterator();
while (i.hasNext()) {
EORelationship r=i.next();
DMEOEntity e=getDMModel().getDMEOEntity(r.getEntity());
e.setChanged();
}
}
if (getDMEOModel() != null) {
getDMEOModel().notifyReordering(this);
}
if (!isDeserializing() && newName != null && newName.trim().length() > 0 && (getExternalName() == null || getExternalName().equals(ToolBox.convertJavaStringToDBName(oldName)))) {
setExternalName(ToolBox.convertJavaStringToDBName(newName));
}
if (!isDeserializing() && newName != null && newName.trim().length() > 0 && (getEntityClassName() == null || getEntityClassName().equals(oldName))) {
try {
setEntityClassName(newName);
}
catch (      InvalidNameException e) {
}
catch (      DuplicateClassNameException e) {
}
}
}
}
}
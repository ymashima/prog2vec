public class Test {
@Override public void setName(String aName){
if (aName == null) {
return;
}
if (name != null && name.equals(aName)) {
return;
}
String oldName=name;
name=aName;
try {
if (resourceFile != null && !getFile().getName().equals(aName + DOTTED_SCREENSHOT_EXTENSION) && !getFile().getName().equals(aName)) {
if (!getFile().exists()) {
try {
getFile().createNewFile();
}
catch (        IOException e) {
e.printStackTrace();
}
}
boolean b=renameFileTo(name + DOTTED_SCREENSHOT_EXTENSION);
if (!b && logger.isLoggable(Level.WARNING)) {
logger.warning("Could not rename screenshot resource from" + getFile().getName() + " to "+ name);
}
if (b) {
getProject().renameResource(this,name);
}
}
}
catch (  DuplicateResourceException e) {
e.printStackTrace();
name=oldName;
delete();
}
catch (  InvalidFileNameException e) {
if (logger.isLoggable(Level.WARNING)) {
logger.warning("InvalidFileName occured while trying to rename screenshot with name " + name + ". Deleting it.");
}
e.printStackTrace();
name=oldName;
delete();
}
catch (  Exception e) {
if (logger.isLoggable(Level.WARNING)) {
logger.warning("An exception occured while trying to rename screenshot with name " + name + ". Deleting it.");
}
e.printStackTrace();
name=oldName;
delete();
}
}
}
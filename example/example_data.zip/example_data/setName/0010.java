public class Test {
@Override public void setName(String newName) throws IllegalArgumentException, InvalidNameException {
if ((name == null) || (!name.equals(newName))) {
if (!isDeserializing() && (newName == null || !DMRegExp.ENTITY_NAME_PATTERN.matcher(newName).matches())) {
throw new InvalidNameException("'" + newName + "' is not a valid name for relationship.");
}
DMEntity containerEntity=getEntity();
if (getEORelationship() != null) {
boolean isClassProperty=_eoRelationship.getIsClassProperty();
EOEntity entity=_eoRelationship.getEntity();
if (entity != null) {
entity.removeRelationship(_eoRelationship);
}
_eoRelationship.setName(newName);
if (entity != null) {
try {
entity.addRelationship(_eoRelationship);
}
catch (        IllegalArgumentException e) {
_eoRelationship.setName(name);
entity.addRelationship(_eoRelationship);
throw e;
}
_eoRelationship.setIsClassProperty(isClassProperty);
}
}
if (containerEntity != null) {
containerEntity.unregisterProperty(this,false);
}
String oldName=name;
name=newName;
if (containerEntity != null) {
containerEntity.registerProperty(this,false);
}
updateCode();
setChanged();
notifyObservers(new DMPropertyNameChanged(this,oldName,newName));
if (containerEntity != null) {
containerEntity.notifyReordering(this);
}
}
}
}
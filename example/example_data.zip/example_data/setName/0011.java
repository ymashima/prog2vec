public class Test {
@Override public void setName(String newName) throws InvalidNameException, DuplicatePropertyNameException {
if (name == null || !name.equals(newName)) {
if (!isDeserializing() && (newName == null || !DMRegExp.ENTITY_NAME_PATTERN.matcher(newName).matches())) {
throw new InvalidNameException("'" + newName + "' is not a valid name for property.");
}
DMEntity containerEntity=getEntity();
boolean isBindable=containerEntity instanceof ComponentDMEntity && ((ComponentDMEntity)containerEntity).isBindable(this);
boolean mandatory=containerEntity instanceof ComponentDMEntity && ((ComponentDMEntity)containerEntity).isMandatory(this);
boolean settable=containerEntity instanceof ComponentDMEntity && ((ComponentDMEntity)containerEntity).isSettable(this);
if (containerEntity != null) {
if (containerEntity.getProperties().get(newName) != null) {
if (logger.isLoggable(Level.WARNING)) {
logger.warning("You are trying to redefine property " + newName + "("+ getType()+ ") "+ " but property "+ newName+ "("+ containerEntity.getProperties().get(newName).getType()+ ") is already existing");
}
throw new DuplicatePropertyNameException(newName);
}
containerEntity.unregisterProperty(this,false);
}
String oldName=name;
name=newName;
if (oldName == null && getFieldName() == null) {
setFieldName(newName);
}
else     if (getFieldName() != null && getFieldName().equals(oldName)) {
setFieldName(newName);
}
if (containerEntity != null) {
containerEntity.registerProperty(this,false,isBindable);
if (containerEntity instanceof ComponentDMEntity) {
((ComponentDMEntity)containerEntity).setSettable(this,settable);
((ComponentDMEntity)containerEntity).setMandatory(this,mandatory);
}
}
updateCode();
setChanged();
notifyObservers(new DMPropertyNameChanged(this,oldName,newName));
if (containerEntity != null) {
containerEntity.notifyReordering(this);
}
}
}
}
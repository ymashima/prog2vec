public class Test {
public void setName(String _name,boolean _fireEvents) throws DuplicateNameException {
String oldName=getName();
String newName=(String)_prototypeValueIfNull(AbstractEOArgument.NAME,_name);
if (newName == null) {
throw new NullPointerException(Messages.getString("EOAttribute.noBlankAttributeNames"));
}
if (myEntity != null) {
myEntity._checkForDuplicateAttributeName(this,newName,null);
EOModel model=myEntity.getModel();
if (model != null) {
model.getModelEvents().addEvent(new EOAttributeRenamedEvent(this));
}
}
super.setName((String)_nullIfPrototyped(AbstractEOArgument.NAME,newName),_fireEvents);
if (myEntity != null && myEntity.getModel() != null) {
for (    EOEntity childrenEntity : myEntity.getChildrenEntities()) {
EOAttribute childAttribute=childrenEntity.getAttributeNamed(oldName);
if (childAttribute != null) {
childAttribute.setName(newName,_fireEvents);
}
}
EOModelGroup modelGroup=myEntity.getModel().getModelGroup();
for (    EOEntity entity : modelGroup.getEntities()) {
for (      EOAttribute attribute : entity.getAttributes()) {
attribute.updateDefinitionBecauseAttributeNameChanged(this);
}
}
for (    EOEntityIndex index : getReferencingEntityIndexes()) {
index.getEntity().setEntityDirty(true);
}
for (    EORelationship relationship : getReferencingRelationships(true,new VerificationContext(getEntity().getModel().getModelGroup()))) {
relationship.getEntity().setEntityDirty(true);
}
}
if (_fireEvents) {
synchronizeNameChange(oldName,newName);
}
}
}
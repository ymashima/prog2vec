public class Test {
/**
* <p>Sets the name of this field</p>
* @param name The new name to put in this field
* @param swapIfNeeded If true, attempting to set this field's nameto a name that is already taken in the object will result in this field's taking the new name from the other field and giving that other field its own name.  Only intended for use by setXML(), which has higher-level code to check for uniqueness of names in an XML schema definition.
*/
public synchronized ReturnVal setName(String name,boolean swapIfNeeded){
securityCheck();
if (isEditingProtectedBuiltInField()) {
return Ganymede.createErrorDialog(ts.l("global.schema_editing_error"),ts.l("setName.system_field"));
}
if (name == null || name.equals("")) {
return Ganymede.createErrorDialog(ts.l("global.schema_editing_error"),ts.l("setName.null_name"));
}
if (name.equals(field_name)) {
return null;
}
if (!XMLNameValidator.isValidGanymedeName(name)) {
return Ganymede.createErrorDialog(ts.l("global.schema_editing_error"),ts.l("setName.invalid_ganymede_name",name));
}
DBObjectBaseField otherField=(DBObjectBaseField)((DBObjectBase)getBase()).getField(name);
if (otherField != null) {
if (!swapIfNeeded) {
return Ganymede.createErrorDialog(ts.l("global.schema_editing_error"),ts.l("setName.duplicate_name",name));
}
else {
String oldName=this.field_name;
this.field_name=name;
ReturnVal retVal=otherField.setName(oldName);
if (!ReturnVal.didSucceed(retVal)) {
return retVal;
}
}
}
field_name=name;
return null;
}
}
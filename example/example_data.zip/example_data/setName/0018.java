public class Test {
/**
* Overrides setName
* @see org.openflexo.foundation.rm.cg.CGRepositoryFileResource#setName(java.lang.String)
*/
@Override public void setName(String aName){
if (aName == null) {
return;
}
if (aName.equals(super.getName())) {
return;
}
String old=super.getName();
super.setName(aName);
if (!isDeleted() && !project.isDeserializing()) {
if (old != null) {
try {
getProject().renameResource(this,aName);
}
catch (      DuplicateResourceException e) {
e.printStackTrace();
super.setName(old);
}
}
if (getResourceToCopy() != null && getFileName() != null && getResourceToCopy().getFileName() != null && !getFileName().equals(getResourceToCopy().getFileName())) {
try {
renameFileTo(getResourceToCopy().getFileName());
}
catch (      InvalidFileNameException e) {
e.printStackTrace();
}
catch (      IOException e) {
e.printStackTrace();
}
}
}
}
}
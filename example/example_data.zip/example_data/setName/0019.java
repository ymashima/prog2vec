public class Test {
@SuppressWarnings("static-access") @Command(aliases={"name","tag"},usage={"ｧ2 - /settlement set name (-name <slogan>) ([-settlement <settlement name>]) ","ｧa  \u00bbSets the name of <settlement name> (or you current focus if a Settlement is not specified)"},shortUsage={"ｧ2 - /settlement set name","ｧa  \u00bbChange the settlement's name."},permission=SET_PERMISSION + ".name",useCommandArguments=true,valueFlags={"settlement","name"}) public boolean setName(CommandSender sender,CommandArguments args){
if (!SettlementUtil.checkCommandValid(sender,SET_PERMISSION + ".name")) {
return true;
}
SettlementPlayer sPlayer=server.getSettlementPlayer((Player)sender);
Settlement settlement=SettlementUtil.getFocusedOrStated(sPlayer,args);
if (settlement == null) {
SettlementMessenger.sendInvalidSettlementMessage(sender);
return true;
}
if (args.hasFlagValue("name")) {
if (sPlayer.getRank(settlement).isEqualOrSuperiorTo(Rank.MODERATOR)) {
settlement.changeName(args.getFlagValue("name"),sPlayer);
return true;
}
else {
settlement.sendNoRightsMessage(sender);
return true;
}
}
else   if (!settlement.getName().equalsIgnoreCase(StringUtil.arrayAsString(args.getUnprocessedArgArray()))) {
if (sPlayer.getRank(settlement).isEqualOrSuperiorTo(Rank.MODERATOR)) {
settlement.changeName(StringUtil.arrayAsString(args.getUnprocessedArgArray()),sPlayer);
return true;
}
else {
settlement.sendNoRightsMessage(sender);
return true;
}
}
else {
return false;
}
}
}
public class Test {
public void setName(String name){
if ((name != null) && (name.length() > 0)) {
this.fullName=name;
StringTokenizer token=new StringTokenizer(name);
int countWithoutFirstAndLast=token.countTokens() - 2;
if (token.hasMoreTokens()) {
this.firstName=token.nextToken();
if (countWithoutFirstAndLast >= 1) {
StringBuffer middleName=new StringBuffer();
for (int i=0; i < countWithoutFirstAndLast; i++) {
middleName.append(token.nextToken());
if (i != (countWithoutFirstAndLast - 1)) {
middleName.append(" ");
}
}
this.middleName=middleName.toString();
}
else {
this.middleName=null;
}
if (countWithoutFirstAndLast >= 0) {
this.lastName=token.nextToken();
}
else {
this.lastName=null;
}
}
else {
System.out.println("com.idega.util.text.Name fullname is an empty string!");
}
}
}
}
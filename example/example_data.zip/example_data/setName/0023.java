public class Test {
/**
* Set the name of this historic query. If the query has already been prepared this will send the change to the API.
* @param name
* @throws EInvalidData
* @throws EAPIError
* @throws EAccessDenied
*/
public void setName(String name) throws EInvalidData, EAPIError, EAccessDenied {
if (_deleted) {
throw new EInvalidData("Cannot set the name of a deleted historic");
}
if (_playback_id.length() == 0) {
_name=name;
}
else {
try {
HashMap<String,String> params=new HashMap<String,String>();
params.put("id",_playback_id);
params.put("name",name);
_user.callAPI("historics/update",params);
reloadData();
}
catch (    EAPIError e) {
switch (e.getCode()) {
case 400:
throw new EInvalidData(e.getMessage());
default :
throw new EAPIError("Unexpected APIError code: " + e.getCode() + " ["+ e.getMessage()+ "]");
}
}
}
}
}
public class Test {
/**
* Sets the name of the global variable as a reserved name. The name is required and can not be <i>null</i>.
* @param name element representing the name of the variable. The name can be a string of a name from the list of reserved system variable names.
* @throws XMLException if the name is null.
*/
@Override public void setName(Object name) throws XMLException {
if (name == null)   throw new XMLException("Null name.");
if (name instanceof String) {
String n, a;
Integer i, p=null;
n=(String)name;
if ("".equals(n.trim()))     throw new XMLException("Empty role String");
i=n.indexOf("(");
if (i > 0) {
a=n.substring(i + 1,n.length() - 1);
n=n.substring(0,i);
p=new Integer(a);
}
NCLSystemVariable v=NCLSystemVariable.getEnumType(n);
if (v != null)     this.name=v;
if (p != null)     setParamenter(p);
this.name=name;
}
else   if (name instanceof NCLSystemVariable) {
this.name=name;
}
else {
throw new XMLException("Wrong name type.");
}
}
}
public class Test {
private void setName(){
if (this.args.shortName != null) {
this.nameToPrint=this.args.shortName;
}
else {
if (this.instanceDestroy != null) {
this.nameToPrint="workspace " + EPRUtils.getIdFromEPR(this.epr);
}
else     if (this.groupDestroy != null) {
this.nameToPrint="group \"" + EPRUtils.getGroupIdFromEPR(this.epr) + "\"";
}
else     if (this.ensembleDestroy != null) {
this.nameToPrint="ensemble \"" + EPRUtils.getEnsembleIdFromEPR(this.epr) + "\"";
}
final String service=StringUtils.commonAtServiceAddressSuffix(this.epr);
if (service != null) {
this.nameToPrint+=service;
}
}
if (this.pr.enabled()) {
final String dbg="Name to print: '" + this.nameToPrint + "'";
if (this.pr.useThis()) {
this.pr.dbg(dbg);
}
else     if (this.pr.useLogging()) {
logger.debug(dbg);
}
}
}
}
public class Test {
@Override public void setName(String newName) throws DuplicateMethodSignatureException {
if (name == null || !name.equals(newName)) {
DMEntity containerEntity=getEntity();
String oldName=name;
name=newName;
_signatureFQ=null;
_signatureNFQ=null;
if (logger.isLoggable(Level.FINE)) {
logger.fine("Change from " + oldName + " to "+ newName+ " new signature is "+ getSignature());
}
if (!isDeserializing() && getEntity() != null && getEntity().getDeclaredMethod(getSignature()) != null) {
name=oldName;
throw new DuplicateMethodSignatureException(getSignature());
}
try {
updateSignature();
setChanged();
notifyObservers(new DMMethodNameChanged(this,oldName,newName));
if (containerEntity != null) {
containerEntity.notifyReordering(this);
}
}
catch (    DuplicateMethodSignatureException e) {
logger.warning("Exception raised: " + e.getClass().getName() + ". See console for details.");
e.printStackTrace();
}
updateCode();
}
}
}
public class Test {
@Override public void setName(final String name) throws AuthException {
try {
ACCOUNT_NAME_CHECKER.check(name);
}
catch (  InvalidValueException e) {
Debugging.logError(LOG,e,"Invalid account name " + name);
throw new AuthException(AuthException.INVALID_NAME,e);
}
try {
(new DatabaseAuthProvider()).lookupAccountByName(name);
}
catch (  AuthException ae) {
try {
DatabaseAuthUtils.invokeUnique(AccountEntity.class,"accountNumber",this.delegate.getAccountNumber(),new Tx<AccountEntity>(){
public void fire(        AccountEntity t){
t.setName(name);
}
}
);
}
catch (    Exception e) {
Debugging.logError(LOG,e,"Failed to setName for " + this.delegate);
throw new AuthException(e);
}
return;
}
throw new AuthException(AuthException.ACCOUNT_ALREADY_EXISTS);
}
}
public class Test {
public void setName(String name){
Connection conn=null;
PreparedStatement ps=null;
try {
conn=iConomy.getiCoDatabase().getConnection();
ps=conn.prepareStatement("UPDATE " + Constants.SQLTable + "_Banks SET name = ? WHERE id = ?");
ps.setString(1,name);
ps.setInt(2,this.id);
ps.executeUpdate();
this.name=name;
}
catch (  Exception ex) {
System.out.println("[iConomy] Failed to update bank name: ");
ex.printStackTrace();
}
finally {
if (ps != null)     try {
ps.close();
}
catch (    SQLException ex) {
}
if (conn != null)     try {
conn.close();
}
catch (    SQLException ex) {
}
}
}
}
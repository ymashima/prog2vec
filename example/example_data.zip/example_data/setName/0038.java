public class Test {
/**
* Sets the name.
* @param value The value to handle.
*/
void setName(String value){
name="";
if (value == null || value.trim().length() == 0) {
if (location == null)     name=NO_LOCATION;
else {
if (location.getDataObject() instanceof ScreenData || location.isDefaultScreen()) {
name+=location.toString();
}
else {
DataNode parent=location.getParent();
if (parent != null && !parent.isDefaultNode() && !location.isDefaultNode())         name=parent.toString() + "/";
name+=location.toString();
}
}
}
else {
if (location == null)     name=value;
else {
DataNode parent=location.getParent();
if (parent != null && !parent.isDefaultNode())       name=parent.toString() + "/";
name+=value;
}
}
}
}
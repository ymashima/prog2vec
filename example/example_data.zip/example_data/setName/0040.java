public class Test {
/**
* {@inheritDoc} <br/>Overridden to always compute the class name and the object number.
* @see org.xwiki.model.reference.EntityReference#setName(java.lang.String)
*/
@Override protected void setName(String name){
super.setName(name);
String classReferenceStr;
String objectNumberStr;
Matcher matcher=NUMBERPATTERN.matcher(name);
if (matcher.find()) {
if (matcher.group(1).length() % 2 == 0) {
classReferenceStr=name.substring(0,matcher.end(1));
objectNumberStr=matcher.group(2);
}
else {
classReferenceStr=name;
objectNumberStr=null;
}
}
else {
classReferenceStr=name;
objectNumberStr=null;
}
this.xclassReference=RESOLVER.resolve(classReferenceStr);
if (objectNumberStr != null) {
this.objectNumber=Integer.valueOf(objectNumberStr);
}
}
}
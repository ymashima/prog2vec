public class Test {
/**
* Sets the name of the property element. This attribute is required and can not be set to <i>null</i>. <br/> A property element may represent an attribute or group of attributes of a node element. <br/> If the property element is a child of a media element with type <i>settings</i>, than it indicates the use of a global variable in the list defined by the document.
* @param name string, element from the enumeration <i>NCLNodeAttributes</i> or global variable representing the name of the property element.
* @throws XMLException if the name is null.
*/
@Override public void setName(Object name) throws XMLException {
if (name == null)   throw new XMLException("Null name.");
Object aux;
if (name instanceof String) {
String var=(String)name;
if ((aux=NCLNodeAttributes.getEnumType(var)) != null)     name=aux;
aux=this.name;
this.name=name;
}
else   if (name instanceof NCLNodeAttributes) {
aux=this.name;
this.name=name;
}
else   if (name instanceof NCLVariable) {
aux=this.name;
this.name=name;
((Ev)name).addReference(this);
}
else   throw new XMLException("Wrong name type.");
notifyAltered(NCLElementAttributes.NAME,aux,name);
if (aux != null && aux instanceof NCLVariable)   ((Ev)name).removeReference(this);
}
}
public class Test {
/**
* Sets the name attribute of the input element.
* @param name the name to use.
*/
public void setName(String name) throws JspException {
name=evaluateString("ContentBooleanFieldTag","name",name);
if (languageDependent) {
try {
String languageIdString=getPropertySet().getString("languageId");
if (languageIdString != null) {
LanguageVO languageVO=LanguageController.getController().getLanguageVOWithId(new Integer(languageIdString));
if (languageVO != null)         languageCode=languageVO.getLanguageCode();
}
}
catch (    Exception e) {
e.printStackTrace();
}
}
getElement().addAttribute("name",name);
if (languageCode == null || languageCode.equals("")) {
checked=getPropertySet().getDataString(name);
}
else {
checked=getPropertySet().getDataString(languageCode + "_" + name);
if (checked == null || checked.equals(""))     checked=getPropertySet().getDataString(name);
}
}
}
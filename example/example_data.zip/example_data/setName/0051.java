public class Test {
/**
* Overrides setName
* @throws DuplicateDKVObjectException
* @see org.openflexo.foundation.dkv.DKVObject#setName(java.lang.String)
*/
@Override public void setName(String name) throws DuplicateDKVObjectException {
if (name.equals(getName())) {
return;
}
if (isDeserializing()) {
super.setName(name);
}
else {
if (domain.getKeyNamed(name) != null) {
throw new DuplicateDKVObjectException(this);
}
boolean reg_unreg=domain.getKeys().indexOf(this) > -1;
if (reg_unreg) {
domain.removeFromKeys(this);
}
super.setName(name);
if (reg_unreg) {
domain.addToKeys(this);
}
}
}
}
public class Test {
public void setName(String username,String name) throws UserNotFoundException {
if (primaryProvider != null)   try {
primaryProvider.setName(username,name);
return;
}
catch (  Exception e) {
}
if (secondaryProvider != null) {
try {
secondaryProvider.setName(username,name);
return;
}
catch (    Exception e) {
}
}
if (tertiaryProvider != null) {
try {
tertiaryProvider.setName(username,name);
return;
}
catch (    Exception e) {
throw new UserNotFoundException();
}
}
}
}
public class Test {
/**
* Setter for scope name
* @param name Scope name
*/
@Override public void setName(String name){
log.debug("Set name: {}",name);
if (oName != null) {
JMXAgent.unregisterMBean(oName);
oName=null;
}
this.name=name;
if (StringUtils.isNotBlank(name)) {
try {
String className=getClass().getName();
if (className.indexOf('.') != -1) {
className=className.substring(className.lastIndexOf('.') + 1);
}
oName=new ObjectName(JMXFactory.getDefaultDomain() + ":type=" + className+ ",name="+ name);
}
catch (    MalformedObjectNameException e) {
log.error("Invalid object name. {}",e);
}
JMXAgent.registerMBean(this,this.getClass().getName(),ScopeMXBean.class,oName);
}
}
}
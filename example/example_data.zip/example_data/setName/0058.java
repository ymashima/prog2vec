public class Test {
/**
* {@inheritDoc} <br/>Overridden to always compute the class name and the object number.
* @see org.xwiki.model.reference.EntityReference#setName(java.lang.String)
*/
@Override protected void setName(String name){
super.setName(name);
className=name;
objectNumber=null;
int closePosition=name.lastIndexOf(']');
if (closePosition < 0 || closePosition != name.length() - 1) {
return;
}
int openPosition=name.lastIndexOf('[');
if (openPosition < 0) {
return;
}
String numberString=name.substring(openPosition + 1,closePosition);
try {
objectNumber=Integer.parseInt(numberString);
className=name.substring(0,openPosition);
}
catch (  NumberFormatException e) {
return;
}
}
}
public class Test {
public void setName(String lastName,String firstName,String middleInitial,String customerId) throws CustomerNotFoundException, InvalidParameterException {
Debug.print("CustomerControllerBean setName");
if (lastName == null) {
throw new InvalidParameterException("null lastName");
}
if (firstName == null) {
throw new InvalidParameterException("null firstName");
}
if (customerId == null) {
throw new InvalidParameterException("null customerId");
}
if (customerExists(customerId) == false) {
throw new CustomerNotFoundException(customerId);
}
try {
LocalCustomer customer=customerHome.findByPrimaryKey(customerId);
customer.setLastName(lastName);
customer.setFirstName(firstName);
customer.setMiddleInitial(middleInitial);
}
catch (  Exception ex) {
throw new EJBException("setName: " + ex.getMessage());
}
}
}
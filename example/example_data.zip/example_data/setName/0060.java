public class Test {
public PsiElement setName(@NonNls @NotNull String name) throws IncorrectOperationException {
boolean renameFile=isRenameFileOnClassRenaming();
final String oldName=getName();
PsiImplUtil.setName(name,getNameIdentifierGroovy());
final GrTypeDefinitionBody body=getBody();
if (body != null) {
for (    PsiMethod method : body.getMethods()) {
if (method.isConstructor() && method.getName().equals(oldName))       method.setName(name);
}
}
if (renameFile) {
final PsiFile file=getContainingFile();
final VirtualFile virtualFile=file.getVirtualFile();
final String ext;
if (virtualFile != null) {
ext=virtualFile.getExtension();
}
else {
ext=GroovyFileType.GROOVY_FILE_TYPE.getDefaultExtension();
}
file.setName(name + "." + ext);
}
return this;
}
}
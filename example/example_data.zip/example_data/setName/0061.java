public class Test {
/**
* Commits a changed Name <=> GUID mapping.
* @param session use this specific Persistence (JPA / EclipseLink) session
* @param guid the guid for which to change the mapped name
* @param newProjectName the new name for all projects with this <code>guid</code>
*/
public synchronized void setName(EntityManager session,String guid,String newProjectName){
if (guid == null || newProjectName == null) {
return;
}
final Query q=session.createQuery("select projectName from ProjectNamePO projectName where projectName.hbmGuid = :projectGuid");
q.setParameter("projectGuid",guid);
IProjectNamePO projectName=null;
try {
projectName=(IProjectNamePO)q.getSingleResult();
}
catch (  NoResultException nre) {
projectName=PoMaker.createProjectNamePO(guid,newProjectName);
session.persist(projectName);
}
projectName.setName(newProjectName);
m_names.put(projectName.getGuid(),projectName.getName());
m_transientNames.remove(guid);
}
}
public class Test {
public void setName(String _name,boolean _fireEvents) throws DuplicateNameException {
if (_name == null) {
throw new NullPointerException(Messages.getString("EORelationship.noBlankRelationshipNames"));
}
String oldName=myName;
if (myEntity != null) {
myEntity._checkForDuplicateRelationshipName(this,_name,null);
}
myName=_name;
if (myEntity != null && myEntity.getModel() != null) {
EOModelGroup modelGroup=myEntity.getModel().getModelGroup();
for (    EOEntity entity : modelGroup.getEntities()) {
for (      EOAttribute attribute : entity.getAttributes()) {
attribute.updateDefinitionBecauseRelationshipNameChanged(this);
}
for (      EORelationship relationship : entity.getRelationships()) {
relationship.updateDefinitionBecauseRelationshipNameChanged(this);
}
}
}
if (_fireEvents) {
firePropertyChange(EORelationship.NAME,oldName,myName);
}
}
}
public class Test {
public void setName(String name){
if (name == null) {
return;
}
String saneFile=fileName.replace('\\','/');
int lastSlash=saneFile.lastIndexOf('/');
String onlyFileName=saneFile.substring(lastSlash + 1,fileName.length());
if (!builtFromString) {
int lastDot=onlyFileName.lastIndexOf('.');
String onlyFileNameNoSuffix=null;
if (lastDot < 0) {
ErrorManager.error(ErrorManager.MSG_FILENAME_EXTENSION_ERROR,fileName);
onlyFileNameNoSuffix=onlyFileName + GRAMMAR_FILE_EXTENSION;
}
else {
onlyFileNameNoSuffix=onlyFileName.substring(0,lastDot);
}
if (!name.equals(onlyFileNameNoSuffix)) {
ErrorManager.error(ErrorManager.MSG_FILE_AND_GRAMMAR_NAME_DIFFER,name,fileName);
}
}
this.name=name;
}
}
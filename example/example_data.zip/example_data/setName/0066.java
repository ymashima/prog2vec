public class Test {
/**
* Changes the name of the agent in the server. The server may have this functionality disabled for all the agents or for this agent in particular. If the agent is not allowed to change his name then an exception will be thrown with a service_unavailable error code.
* @param newName the new name of the agent.
* @throws XMPPException if the agent is not allowed to change his name or no response wasobtained from the server.
*/
public void setName(String newName) throws XMPPException {
AgentInfo agentInfo=new AgentInfo();
agentInfo.setType(IQ.Type.SET);
agentInfo.setTo(workgroupJID);
agentInfo.setFrom(getUser());
agentInfo.setName(newName);
PacketCollector collector=connection.createPacketCollector(new PacketIDFilter(agentInfo.getPacketID()));
connection.sendPacket(agentInfo);
IQ response=(IQ)collector.nextResult(SmackConfiguration.getPacketReplyTimeout());
collector.cancel();
if (response == null) {
throw new XMPPException("No response from server on status set.");
}
if (response.getError() != null) {
throw new XMPPException(response.getError());
}
return;
}
}
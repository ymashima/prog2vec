public class Test {
void setName(String name) throws NameConstraintViolationException {
if (name == null || name.length() == 0) {
throw new NameConstraintViolationException("Name can't be null or empty string.");
}
if (name.equals(getName())) {
return;
}
try {
if (node.getParent().hasNode(name)) {
throw new NameConstraintViolationException("Object with name " + name + " already exists.");
}
if (name != null) {
Session session=node.getSession();
String srcPath=path();
String destPath=srcPath.substring(0,srcPath.lastIndexOf('/') + 1) + name;
session.move(srcPath,destPath);
node=(Node)session.getItem(destPath);
}
}
catch (  RepositoryException re) {
throw new CmisRuntimeException("Unable set object name. " + re.getMessage(),re);
}
}
}
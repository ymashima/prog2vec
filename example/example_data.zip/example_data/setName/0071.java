public class Test {
/**
* Updates the name of the user using the userService/update service.
* @param username the username of the user
* @param name     the new name of the user
* @throws UserNotFoundException if there is no user with that username
*/
public void setName(String username,String name) throws UserNotFoundException {
if (isReadOnly()) {
throw new UnsupportedOperationException();
}
try {
Element userUpdateParams=getUserUpdateParams(username);
String[] path=new String[]{"user","name"};
WSUtils.modifyElementText(userUpdateParams,path,name);
updateUser(userUpdateParams);
}
catch (  UserNotFoundException e) {
throw e;
}
catch (  Exception e) {
throw new UserNotFoundException(e);
}
}
}
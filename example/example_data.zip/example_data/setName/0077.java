public class Test {
private void setName(String name){
if (name == null) {
throw new IllegalArgumentException("Cookie name was null");
}
else   if (name.indexOf(";") != -1) {
throw new IllegalArgumentException("Cookie name contains a semicolon");
}
else   if (name.indexOf(",") != -1) {
throw new IllegalArgumentException("Cookie name contains a comma");
}
else   if (name.startsWith("$")) {
throw new IllegalArgumentException("Cookie name starts with $");
}
else {
for (int n=0; n < name.length(); n++) {
char c=name.charAt(n);
if (c <= 0x20 || c >= 0x7f) {
throw new IllegalArgumentException("Cookie name contains whitespace or " + "non-alphanumeric char: " + name.charAt(n) + " in "+ name);
}
}
this.name=name;
}
}
}
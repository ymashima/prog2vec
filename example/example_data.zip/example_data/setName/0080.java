public class Test {
synchronized public String setName() throws IOException {
if (name != null && !name.isEmpty())   return name;
name=conf.get("distributed.manager.name");
if (name != null && !name.isEmpty())   return name;
name=conf.get("distributed.data.client.class.name");
if (name != null && !name.isEmpty()) {
if (name.contains("."))     name=name.split("\\.")[name.split("\\.").length - 1];
return name;
}
name=DistributedData.getDataClientClassName(conf.get("distributed.data.class.name"));
if (name != null && !name.isEmpty()) {
if (name.contains("."))     name=name.split("\\.")[name.split("\\.").length - 1];
return name;
}
List<String> nameList=getNameList();
if (!nameList.isEmpty()) {
name=nameList.get(0);
log(Level.WARN," randomly choose name=",name," in ",Utilities.deepToString(nameList));
return name;
}
throw new IOException("need to specify distributed.manager.name or start one distributed server at least");
}
}
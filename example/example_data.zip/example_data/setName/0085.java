public class Test {
public void setName(String _name) throws SubscriptionException {
if (!name.equals(_name)) {
boolean ok=false;
String old_name=name;
int old_version=version;
try {
name=_name;
version++;
SubscriptionBodyImpl body=new SubscriptionBodyImpl(manager,this);
syncToBody(body);
versionUpdated(body,false);
ok=true;
}
finally {
if (!ok) {
name=old_name;
version=old_version;
}
}
fireChanged();
}
}
}
public class Test {
/**
* Sets the name attribute of the textarea element.  As an side-effect, the value will also be set, where the value is fetched from the propertyset using the specified name.
* @param name the name to use.
*/
public void setName(final String name){
String languageCode=null;
if (languageDependent) {
try {
String languageIdString=getPropertySet().getString("languageId");
if (languageIdString != null) {
LanguageVO languageVO=LanguageController.getController().getLanguageVOWithId(new Integer(languageIdString));
if (languageVO != null)         languageCode=languageVO.getLanguageCode();
}
}
catch (    Exception e) {
e.printStackTrace();
}
}
getElement().addAttribute("name",name);
if (languageCode == null || languageCode.equals(""))   getElement().addText(getPropertySet().getDataString(name));
else   getElement().addText(getPropertySet().getDataString(languageCode + "_" + name));
}
}
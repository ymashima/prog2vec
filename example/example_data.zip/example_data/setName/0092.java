public class Test {
public void setName(String name){
Name=name;
int extDot=name.lastIndexOf('.');
if (extDot > 0) {
String extension=name.substring(extDot + 1);
if ("bmp".equals(extension)) {
mime="image/bmp";
}
else     if ("jpg".equals(extension)) {
mime="image/jpeg";
}
else     if ("gif".equals(extension)) {
mime="image/gif";
}
else     if ("png".equals(extension)) {
mime="image/png";
}
else {
mime="image/unknown";
}
}
}
}
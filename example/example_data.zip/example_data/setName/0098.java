public class Test {
public void setName(String name){
String oldName=_name;
_name=name;
if (_namePosition != null && _name != null) {
setNamePosition(new Position(_namePosition.getOffset(),_name.length()));
}
int oldLength;
if (oldName != null) {
oldLength=oldName.length();
}
else {
oldLength=0;
}
int newLength=name.length();
int diff=newLength - oldLength;
if (_valueNamespacePosition != null) {
setValueNamespacePosition(new Position(_valueNamespacePosition.getOffset() + diff,_valueNamespacePosition.getLength()));
}
if (_valuePosition != null) {
setValuePosition(new Position(_valuePosition.getOffset() + diff,_valuePosition.getLength()));
}
}
}
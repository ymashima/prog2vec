public class Test {
/**
* Sets the name of the object. <p> setName (String newName) changes the name of the object in the file.
* @param newName The new name of the object.
*/
public void setName(String newName) throws Exception {
if (newName != null) {
if (newName.equals(HObject.separator)) {
throw new IllegalArgumentException("The new name cannot be the root");
}
if (newName.startsWith(HObject.separator)) {
newName=newName.substring(1);
}
if (newName.endsWith(HObject.separator)) {
newName=newName.substring(0,newName.length() - 2);
}
if (newName.contains(HObject.separator)) {
throw new IllegalArgumentException("The new name contains the separator character: " + HObject.separator);
}
}
name=newName;
}
}
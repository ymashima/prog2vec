public class Test {
public PsiElement setName(@NotNull final String nameText) throws IncorrectOperationException {
final ASTNode name=XmlChildRole.ATTRIBUTE_NAME_FINDER.findChild(this);
final String oldName=name.getText();
final PomModel model=PomManager.getModel(getProject());
final XmlAttribute attribute=XmlElementFactory.getInstance(getProject()).createXmlAttribute(nameText,"");
final ASTNode newName=XmlChildRole.ATTRIBUTE_NAME_FINDER.findChild((ASTNode)attribute);
final XmlAspect aspect=model.getModelAspect(XmlAspect.class);
model.runTransaction(new PomTransactionBase(getParent(),aspect){
public PomModelEvent runInner(){
final PomModelEvent event=new PomModelEvent(model);
final XmlAspectChangeSetImpl xmlAspectChangeSet=new XmlAspectChangeSetImpl(model,(XmlFile)getContainingFile());
xmlAspectChangeSet.add(new XmlAttributeSetImpl(getParent(),oldName,null));
xmlAspectChangeSet.add(new XmlAttributeSetImpl(getParent(),nameText,getValue()));
event.registerChangeSet(model.getModelAspect(XmlAspect.class),xmlAspectChangeSet);
CodeEditUtil.replaceChild(XmlAttributeImpl.this,name,newName);
return event;
}
}
);
return this;
}
}
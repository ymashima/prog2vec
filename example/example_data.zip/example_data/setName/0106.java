public class Test {
@Override public void setName(String name) throws LayerException {
SourceManager sourceManager=((DataManager)Services.getService(DataManager.class)).getDataSourceFactory().getSourceManager();
if (!mainName.equals(getName())) {
sourceManager.removeName(getName());
}
if (!name.equals(mainName)) {
super.setName(name);
try {
sourceManager.addName(mainName,name);
}
catch (    NoSuchTableException e) {
throw new RuntimeException(I18N.getString("orbisgis-core.org.orbisgis.layerModel.gdmsLayer.bug"),e);
}
catch (    SourceAlreadyExistsException e) {
throw new LayerException(I18N.getString("orbisgis-core.org.orbisgis.layerModel.gdmsLayer.sourceAlreadyExists"),e);
}
}
else {
super.setName(name);
}
}
}
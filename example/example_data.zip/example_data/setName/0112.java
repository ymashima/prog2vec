public class Test {
/**
* This method sets the name of a RubySchema to the name given. It's important to note that if the RubySchema represents anything other than a tuple, databag, or map then an error will be thrown.
* @param name a String to set the name of the encapsulated Schema object
*/
private void setName(String name){
Schema.FieldSchema fs;
try {
fs=internalSchema.getField(0);
}
catch (  FrontendException e) {
throw new RuntimeException("Error getting field from schema: " + internalSchema,e);
}
byte type=fs.type;
if (type == DataType.TUPLE || type == DataType.BAG || type == DataType.MAP) {
fs.alias=name;
}
else {
throw new RuntimeException("setName cannot be set on Schema: " + internalSchema);
}
}
}
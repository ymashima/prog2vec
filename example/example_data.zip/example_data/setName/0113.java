public class Test {
/**
* This method allows the user to set the name of the alias of the FieldSchema of the encapsulated Schema. This method only works if the Schema has one FieldSchema.
* @param arg a RubyString to set the name to
* @return    the new name
*/
@JRubyMethod(name="name=") public RubyString setName(IRubyObject arg){
if (arg instanceof RubyString) {
if (internalSchema.size() != 1)     throw new RuntimeException("Can only set name if there is one schema present");
try {
internalSchema.getField(0).alias=arg.toString();
return (RubyString)arg;
}
catch (    FrontendException e) {
throw new RuntimeException("Unable to get field from Schema",e);
}
}
else {
throw new RuntimeException("Improper argument passed to 'name=':" + arg);
}
}
}
public class Test {
public void setName(String name){
clear();
if (name == null) {
return;
}
Iterator itr=nameLookup.keySet().iterator();
while (itr.hasNext()) {
Object key=itr.next();
if (nameLookup.get(key) != null) {
for (      String typeLookup : nameLookup.get(key)) {
if (typeLookup.toLowerCase().equals(name.toLowerCase())) {
setId((Id)key);
return;
}
}
}
}
setId(Id.UNKNOWN);
return;
}
}
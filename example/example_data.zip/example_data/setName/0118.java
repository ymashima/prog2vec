public class Test {
/**
* @param name the name to set
*/
public void setName(String name){
if (name.length() > 2 && name.charAt(0) == '-') {
if (name.charAt(1) == '-') {
this.name=name;
}
else {
this.name="-" + name;
}
}
else   if (name.charAt(0) == '/') {
this.name=name;
}
else {
this.name="--" + name;
}
}
}
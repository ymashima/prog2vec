public class Test {
private void setName(String text){
ISiteModel model=(ISiteModel)getPage().getModel();
ISite site=model.getSite();
ISiteDescription description=site.getDescription();
boolean defined=false;
if (description == null) {
description=model.getFactory().createDescription(null);
defined=true;
}
try {
description.setName(text);
if (defined) {
site.setDescription(description);
}
}
catch (  CoreException e) {
PDEPlugin.logException(e);
}
}
}
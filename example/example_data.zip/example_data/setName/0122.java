public class Test {
/**
* Set the file name.  The name should be exactly eight characters long and it is truncated or left padded with zeros to make this true.
* @param name The file name.
*/
private void setName(String name){
int len=name.length();
if (len > MAX_FILE_LEN) {
this.name=name.substring(0,8);
}
else   if (len < MAX_FILE_LEN) {
StringBuffer sb=new StringBuffer();
for (int i=0; i < MAX_FILE_LEN - len; i++) {
sb.append('0');
}
sb.append(name);
this.name=sb.toString();
}
else   this.name=name;
}
}
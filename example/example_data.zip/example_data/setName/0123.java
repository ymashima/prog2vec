public class Test {
/**
* Sets the logical key/name of this search index source.<p>
* @param name the logical key/name of this search index source
* @throws CmsIllegalArgumentException if argument name is null, an empty or whitespace-only Strings or already used for another indexsource's name.
*/
public void setName(String name) throws CmsIllegalArgumentException {
if (CmsStringUtil.isEmptyOrWhitespaceOnly(name)) {
throw new CmsIllegalArgumentException(Messages.get().container(Messages.ERR_INDEXSOURCE_CREATE_MISSING_NAME_0));
}
if (OpenCms.getRunLevel() > OpenCms.RUNLEVEL_2_INITIALIZING) {
CmsSearchManager mngr=OpenCms.getSearchManager();
if (mngr.getIndexSource(name) != this) {
if (mngr.getSearchIndexSources().keySet().contains(name)) {
throw new CmsIllegalArgumentException(Messages.get().container(Messages.ERR_INDEXSOURCE_CREATE_INVALID_NAME_1,name));
}
}
}
m_name=name;
}
}
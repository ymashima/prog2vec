public class Test {
/**
* Overrides setName
* @see org.openflexo.foundation.dm.eo.model.EOObject#setName(java.lang.String)
*/
@Override public void setName(String name) throws IllegalStateException {
if (getModel() != null) {
EOEntity e=getModel()._entityNamedIgnoreCase(name);
if (e != null) {
throw new IllegalStateException("duplicated entity '" + e.getName() + "'");
}
if ((getName() == null && name != null) || (getName() != null && !getName().equals(name))) {
if (getFile() != null && getFile().exists()) {
getModel().addToFilesToDelete(getFile());
}
setFile(new File(getModel().getFile(),name + ".plist"));
}
}
super.setName(name);
}
}
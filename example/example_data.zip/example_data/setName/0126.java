public class Test {
public static void setName(final DiagramEntity diagramEntity,final String sValue){
CoreArgCheck.isNotNull(diagramEntity);
boolean requiredStart=ModelerCore.startTxn(false,false,"Set DE Name",diagramEntity);
boolean succeeded=false;
try {
diagramEntity.setName(sValue);
succeeded=true;
}
finally {
if (requiredStart) {
if (succeeded) {
ModelerCore.commitTxn();
}
else {
ModelerCore.rollbackTxn();
}
}
}
}
}
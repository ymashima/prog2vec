public class Test {
/**
* Helper to set the 'name' property for the node.
* @param name Name to set
*/
public void setName(String name){
if (name != null) {
QName typeQName=getQNameType();
if ((services.getDictionaryService().isSubClass(typeQName,ContentModel.TYPE_FOLDER) && !services.getDictionaryService().isSubClass(typeQName,ContentModel.TYPE_SYSTEM_FOLDER)) || services.getDictionaryService().isSubClass(typeQName,ContentModel.TYPE_CONTENT)) {
try {
this.services.getFileFolderService().rename(this.nodeRef,name);
}
catch (      FileNotFoundException e) {
throw new AlfrescoRuntimeException("Failed to rename node " + nodeRef + " to "+ name,e);
}
}
this.getProperties().put(ContentModel.PROP_NAME.toString(),name.toString());
}
}
}
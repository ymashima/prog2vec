public class Test {
/**
* Sets the name of this Database.
* @param new name
*/
public void setName(Transaction txn,final String name){
if (txn != null) {
txn.addTxn(this,new Txn(){
public void commit(      Transaction txn){
setNameP(txn,name);
}
}
);
}
else {
setNameP(txn,name);
}
masterPlaylist.setName(txn,name);
}
}
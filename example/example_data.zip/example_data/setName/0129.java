public class Test {
public Object setName(EntityReference ref,Map<String,Object> inputVar,Context context){
if (inputVar.containsKey("value")) {
try {
Group group=Group.find(context,Integer.parseInt(ref.getId()));
if ((group != null)) {
group.setName(inputVar.get("value").toString());
return group.getID();
}
else {
throw new EntityException("Not found","Entity not found",404);
}
}
catch (    SQLException ex) {
throw new EntityException("Internal server error","SQL error",500);
}
}
return null;
}
}
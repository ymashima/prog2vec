public class Test {
public PsiElement setName(@NonNls @NotNull String newName) throws IncorrectOperationException {
String oldName=getName();
boolean isRenameFile=isRenameFileOnClassRenaming();
PsiIdentifier nameIdentifier=(PsiIdentifier)getNameIdentifier().getFirstChild();
com.intellij.psi.impl.PsiImplUtil.setName(nameIdentifier,newName);
if (isRenameFile) {
PsiFile file=(PsiFile)getParent();
String fileName=file.getName();
int dotIndex=fileName.lastIndexOf('.');
file.setName(dotIndex >= 0 ? newName + "." + fileName.substring(dotIndex + 1) : newName);
}
for (  PsiMethod method : getConstructors()) {
if (method.getName().equals(oldName)) {
method.setName(newName);
}
}
return this;
}
}
public class Test {
/**
* Sets the name of the child item.
* @param name a <code>String</code>.
* @throws ConstraintViolationException
*/
public void setName(String name) throws ConstraintViolationException {
if (ItemDefinitionImpl.ANY_NAME.equals(name)) {
this.name=NameConstants.ANY_NAME;
}
else {
try {
this.name=resolver.getQName(name);
}
catch (    RepositoryException e) {
throw new ConstraintViolationException(e);
}
}
}
}
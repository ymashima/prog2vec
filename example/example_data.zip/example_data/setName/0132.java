public class Test {
/**
* This sets the local name of the <code>Attribute</code>.
* @param name the new local name to set
* @return <code>Attribute</code> - the attribute modified.
* @throws IllegalNameException if the given name is illegal as anattribute name.
*/
public Attribute setName(final String name){
if (name == null) {
throw new NullPointerException("Can not set a null name for an Attribute.");
}
final String reason=Verifier.checkAttributeName(name);
if (reason != null) {
throw new IllegalNameException(name,"attribute",reason);
}
this.name=name;
specified=true;
return this;
}
}
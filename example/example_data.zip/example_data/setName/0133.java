public class Test {
/**
* Sets the control name.
* @param name the control name.
*/
public void setName(String name){
if (name == null) {
throw new IllegalArgumentException("Name can not be null.");
}
if (getFormDataContentDisposition() == null) {
FormDataContentDisposition contentDisposition;
contentDisposition=FormDataContentDisposition.name(name).build();
super.setContentDisposition(contentDisposition);
}
else {
FormDataContentDisposition formDataContentDisposition=FormDataContentDisposition.name(name).fileName(contentDisposition.getFileName()).creationDate(contentDisposition.getCreationDate()).modificationDate(contentDisposition.getModificationDate()).readDate(contentDisposition.getReadDate()).size(contentDisposition.getSize()).build();
super.setContentDisposition(formDataContentDisposition);
}
}
}
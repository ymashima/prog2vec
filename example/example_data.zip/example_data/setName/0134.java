public class Test {
/**
* Set the control name.
* @param name the control name.
*/
public void setName(String name){
if (name == null) {
throw new IllegalArgumentException("Name can not be null.");
}
if (getFormDataContentDisposition() == null) {
FormDataContentDisposition contentDisposition;
contentDisposition=FormDataContentDisposition.name(name).build();
super.setContentDisposition(contentDisposition);
}
else {
FormDataContentDisposition _cd=FormDataContentDisposition.name(name).fileName(cd.getFileName()).creationDate(cd.getCreationDate()).modificationDate(cd.getModificationDate()).readDate(cd.getReadDate()).size(cd.getSize()).build();
super.setContentDisposition(_cd);
}
}
}
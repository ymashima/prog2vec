public class Test {
/**
* Change the name of this entry
* @param newName
* @throws IOException
*/
public final void setName(String newName) throws IOException {
log.debug("<<< BEGIN setName newName=" + newName + " >>>");
if (isRoot()) {
log.debug("<<< END setName newName=" + newName + " ERROR: root >>>");
throw new IOException("Cannot change name of root directory");
}
if (table.rename(name,newName) < 0) {
log.debug("<<< END setName newName=" + newName + " ERROR: table can't rename >>>");
throw new IOException("Cannot change name");
}
this.name=newName;
log.debug("<<< END setName newName=" + newName + " >>>");
}
}
public class Test {
public void setName(String name){
NetworkPort networkPort=(NetworkPort)peek();
String[] nameAndUnit=name.split("\\.");
if (nameAndUnit.length == 1) {
networkPort.setName(name);
}
else {
networkPort.setName(nameAndUnit[0]);
int portNumber=-1;
try {
portNumber=Integer.parseInt(nameAndUnit[1]);
}
catch (    NumberFormatException numFormatException) {
return;
}
networkPort.setPortNumber(portNumber);
}
}
}
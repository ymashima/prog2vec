public class Test {
@SuppressWarnings("unchecked") public void setName(String name){
if (name == null) {
throw new NullPointerException("Name can't be null");
}
if (name.length() == 0) {
throw new IllegalArgumentException("Name can't be empty");
}
if (this instanceof Child) {
Child child=(Child)this;
WorkflowBean parent=child.getParent();
if (parent != null) {
child.setParent(null);
this.name=name;
child.setParent(parent);
}
}
this.name=name;
}
}
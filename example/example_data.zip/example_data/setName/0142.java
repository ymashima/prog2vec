public class Test {
/**
* {@inheritDoc}
*/
public void setName(String name) throws ChangeVetoException {
if (!this.hasListeners(RichFeature.NAME)) {
this.name=name;
}
else {
ChangeEvent ce=new ChangeEvent(this,RichFeature.NAME,name,this.name);
ChangeSupport cs=this.getChangeSupport(RichFeature.NAME);
synchronized (cs) {
cs.firePreChangeEvent(ce);
this.name=name;
cs.firePostChangeEvent(ce);
}
}
}
}
public class Test {
private void setName(){
AnnotationMirror nameAnnotation=getAnnotation(Name.class.getName());
if (nameAnnotation != null) {
name=(String)nameAnnotation.getValue();
return;
}
String baseName=toParameterName(typeBinding);
int count=0;
String nameToReturn=baseName;
for (  VariableMirror parameter : methodMirror.getParameters()) {
if (parameter.getName().equals(nameToReturn)) {
count++;
nameToReturn=baseName + Integer.toString(count);
}
}
name=nameToReturn;
}
}
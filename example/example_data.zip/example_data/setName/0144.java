public class Test {
public void setName(String name){
super.setName(name);
if (this.theWholeDate != null) {
this.theWholeDate.setName(name);
}
if (this.theDay != null) {
this.theDay.setName(name + "_day");
}
if (this.theMonth != null) {
this.theMonth.setName(name + "_month");
}
if (this.showYear) {
if (this.theYear != null) {
this.theYear.setName(name + "_year");
}
}
}
}
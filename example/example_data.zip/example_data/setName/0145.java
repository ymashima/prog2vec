public class Test {
/**
* Set the name and namespace URI for a concrete &lt;mapping> binding component. This is the same logic as used in the  {@link StructureClassHolder} equivalent.
* @param qname qualified name to be set (<code>null</code> if none)
* @param mapping concrete mapping definition
* @param holder binding containing the mapping
*/
private void setName(QName qname,MappingElementBase mapping,BindingHolder holder){
if (qname != null) {
String name=qname.getName();
mapping.setName(name);
String uri=qname.getUri();
holder.addNamespaceUsage(uri);
if (!Utility.safeEquals(uri,holder.getElementDefaultNamespace())) {
mapping.setUri(uri);
}
}
}
}
public class Test {
@Override public PsiElement setName(@NotNull String newName) throws IncorrectOperationException {
String oldName=getName();
boolean isRenameFile=isRenameFileOnRenaming();
PsiImplUtil.setName(getNameIdentifier(),newName);
if (isRenameFile) {
PsiFile file=(PsiFile)getParent();
String fileName=file.getName();
int dotIndex=fileName.lastIndexOf('.');
file.setName(dotIndex >= 0 ? newName + "." + fileName.substring(dotIndex + 1) : newName);
}
for (  PsiMethod method : getConstructors()) {
if (method.getName().equals(oldName)) {
method.setName(newName);
}
}
return this;
}
}
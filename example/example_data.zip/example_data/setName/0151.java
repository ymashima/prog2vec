public class Test {
/**
* Sets the name of the Thread.
* @param threadName the new name for the Thread
* @throws SecurityException if <code>checkAccess()</code> fails with aSecurityException
* @see Thread#getName
*/
public final void setName(String threadName){
if (threadName == null) {
throw new NullPointerException();
}
checkAccess();
name=threadName;
VMThread vmt=this.vmThread;
if (vmt != null) {
vmt.nameChanged(threadName);
}
}
}
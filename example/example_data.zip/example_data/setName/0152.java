public class Test {
private void setName(){
if (this.args.shortName != null) {
this.nameToPrint=this.args.shortName;
}
else {
this.nameToPrint="\"" + EPRUtils.getContextIdFromEPR(this.epr) + "\"";
}
if (this.pr.enabled()) {
final String dbg="Name to print: '" + this.nameToPrint + "'";
if (this.pr.useThis()) {
this.pr.dbg(dbg);
}
else     if (this.pr.useLogging()) {
logger.debug(dbg);
}
}
}
}
public class Test {
@Override public void setName(String newName) throws InvalidNameException {
boolean notify=!isDeserializing();
try {
internallyUpdateName(newName);
notify=false;
}
catch (  DuplicateClassNameException e) {
e.printStackTrace();
throw new InvalidNameException(e.getLocalizedMessage());
}
finally {
if (notify) {
setChanged();
notifyObserversAsReentrantModification(new NameChanged(newName,getName()));
}
}
}
}
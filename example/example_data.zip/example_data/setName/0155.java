public class Test {
@Override public void setName(String aName) throws DuplicateStatusException {
if ((statusName == null && aName != null) || (statusName != null && aName == null) || (statusName != null && aName != null && !statusName.equals(aName))) {
if ((getStatusList() != null) && (getStatusList().statusWithName(aName) != null)) {
if (isDeserializing()) {
setName(aName + "-1");
}
throw new DuplicateStatusException(this,aName);
}
String oldValue=statusName;
statusName=aName;
setChanged();
notifyObservers(new WKFAttributeDataModification("name",oldValue,aName));
if (getProcess() != null) {
getProcess().notifyStatusListUpdated();
}
}
}
}
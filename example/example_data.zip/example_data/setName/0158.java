public class Test {
public boolean setName(java.lang.String name) throws android.os.RemoteException {
android.os.Parcel _data=android.os.Parcel.obtain();
android.os.Parcel _reply=android.os.Parcel.obtain();
boolean _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(name);
mRemote.transact(Stub.TRANSACTION_setName,_data,_reply,0);
_reply.readException();
_result=(0 != _reply.readInt());
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
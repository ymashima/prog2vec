public class Test {
public void setName(String s) throws IllegalStateException, IllegalArgumentException {
if (s.length() < 1) {
throw new IllegalArgumentException("setName does not accept a zero length string.");
}
if (mName != null) {
throw new IllegalArgumentException("setName object already has a name.");
}
try {
byte[] bytes=s.getBytes("UTF-8");
mRS.nAssignName(mID,bytes);
mName=s;
}
catch (  java.io.UnsupportedEncodingException e) {
throw new RuntimeException(e);
}
}
}
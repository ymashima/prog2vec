public class Test {
@Override public void setName(String name){
if (name == null || name.isEmpty()) {
return;
}
name=name.toLowerCase();
try {
PreparedStatement ps=DatabaseMySql.getStatement("ALTER TABLE " + tableName + " RENAME ?");
ps.setString(1,name);
if (ps.execute()) {
tableName=name;
}
}
catch (  SQLException e) {
Logman.logStackTrace("Exception while renaming table " + tableName,e);
}
}
}
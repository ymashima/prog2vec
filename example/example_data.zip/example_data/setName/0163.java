public class Test {
/**
* Sets my name.
* @param name my new name
* @throws IllegalArgumentException if the specified name is <code>null</code> or empty, or if it is already used by another configuration in my warking set
*/
void setName(String name){
if ((name == null) || (name.length() == 0)) {
throw new IllegalArgumentException("name is empty");
}
if (!name.equals(getName())) {
if (getWorkingSet().getConfiguration(name) != null) {
throw new IllegalArgumentException("name is already in use");
}
basicSetName(name);
}
}
}
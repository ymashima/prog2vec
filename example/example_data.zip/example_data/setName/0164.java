public class Test {
public void setName(String sName){
XMLElement key=getKeyElement();
XMLElement name=null;
if (key == null) {
key=createKeyElement();
name=new XMLElement(nameTag);
}
else {
name=key.getChild(nameTag);
if (name == null) {
name=new XMLElement(nameTag);
}
}
name.setText(sName);
key.addContent(name);
}
}
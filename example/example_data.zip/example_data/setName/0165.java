public class Test {
/**
* Sets the name of this Library. Note: Library must be open or an <tt>IllegalStateException</tt> will be thrown
*/
public void setName(Transaction txn,final String name){
if (txn != null) {
txn.addTxn(this,new Txn(){
public void commit(      Transaction txn){
setNameP(txn,name);
}
}
);
}
else {
setNameP(txn,name);
}
}
}
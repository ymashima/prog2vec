public class Test {
@Override protected EObject setName(URI targetElementURI,final String newName,ResourceSet resourceSet){
EObject targetElement=super.setName(targetElementURI,newName,resourceSet);
if (targetElement instanceof XNamedElement) {
XNamedElement xNamedElement=(XNamedElement)targetElement;
ENamedElement eNamedElement=mapper.getEcore(xNamedElement);
if (eNamedElement instanceof EPackage) {
XcoreEcoreBuilder.setQualifiedPackageName((EPackage)eNamedElement,newName);
}
else {
eNamedElement.setName(newName);
}
GenBase genBase=mapper.getGen(xNamedElement);
XcoreJvmInferrer.inferName(genBase);
}
return targetElement;
}
}
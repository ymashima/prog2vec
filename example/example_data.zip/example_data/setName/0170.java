public class Test {
/**
* Set the name for this session in the ClusterManager
* @param name the name of this session
* @throws IOException
*/
public void setName(String name) throws IOException {
if (failException != null) {
throw failException;
}
if (name == null || name.length() == 0) {
return;
}
sessionInfo.name=name;
SessionInfo newInfo=new SessionInfo(sessionInfo);
cmNotifier.addCall(new ClusterManagerService.sessionUpdateInfo_args(sessionId,newInfo));
}
}
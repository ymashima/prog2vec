public class Test {
/**
* Changes the name
* @return true if the name change was succesfullfalse if the given name is already in use by the collection
*/
public boolean setName(String name){
if (name.equals(this.name))   return true;
if (variableCollection == null) {
this.name=name;
}
else {
if (variableCollection.get(name) != null)     return false;
this.name=name;
variableCollection.nameChanged(this);
}
return true;
}
}
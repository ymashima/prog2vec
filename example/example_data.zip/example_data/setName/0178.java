public class Test {
public void setName(String name){
String oldName=fName;
if (getModel() != null) {
try {
IBuild build=getModel().getBuild();
build.remove(this);
fName=name;
build.add(this);
}
catch (    CoreException e) {
PDECore.logException(e);
}
getModel().fireModelObjectChanged(this,getName(),oldName,name);
}
else   fName=name;
}
}
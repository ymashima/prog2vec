public class Test {
public void setName(String nameString){
if (nameString == null) {
setId(null);
return;
}
Iterator itr=names.keySet().iterator();
while (itr.hasNext()) {
Object key=itr.next();
for (    String name : names.get(key))     if (name.toLowerCase().equals(nameString.toLowerCase())) {
setId((Id)key);
return;
}
}
setId(Id.UNKNOWN);
return;
}
}
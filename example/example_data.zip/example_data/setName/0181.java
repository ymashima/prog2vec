public class Test {
/**
* Sets the name.
* @param fullName  the non-null full name.
* @param namespace the namespace URI, which may be null.
*/
public void setName(String fullName,String namespace){
int index=fullName.indexOf(':');
if ((namespace == null) || (index < 0)) {
this.name=fullName;
}
else {
this.name=fullName.substring(index + 1);
}
this.fullName=fullName;
this.namespace=namespace;
}
}
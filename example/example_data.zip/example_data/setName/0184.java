public class Test {
/**
* Sets the name of the given  {@link SceneGraphObject}. This method exists to avoid a compile-time dependency on Java3D 1.4+.
*/
public static void setName(SceneGraphObject obj,String name){
if (SGO_SET_NAME != null) {
try {
SGO_SET_NAME.invoke(obj,name);
}
catch (    IllegalAccessException exc) {
}
catch (    InvocationTargetException exc) {
}
}
else {
}
}
}
public class Test {
@Override public void setName(String value){
if (value == null) {
throw new ASBlocksSyntaxError("Type name must not be null");
}
if (value.indexOf('.') != -1) {
throw new ASBlocksSyntaxError("Method name must not contain '.'");
}
if (value.indexOf(':') != -1) {
throw new ASBlocksSyntaxError("Method name must not contain ':'");
}
ASTIterator i=new ASTIterator(ast);
i.find(AS3Parser.IDENT);
LinkedListTree newName=AS3FragmentParser.parseType(value).getFirstChild();
i.replace(newName);
}
}
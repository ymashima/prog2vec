public class Test {
/**
* Sets this product's name.
* @param name The name.
*/
public void setName(final String name){
Guardian.assertNotNull("name",name);
String trimmedName=name.trim();
Guardian.assertNotNullOrEmpty("name contains only spaces",trimmedName);
if (!ObjectUtils.equalObjects(this.name,trimmedName)) {
if (!isValidNodeName(trimmedName)) {
throw new IllegalArgumentException("The given name '" + trimmedName + "' is not a valid node name.");
}
setNodeName(trimmedName);
}
}
}
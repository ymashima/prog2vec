public class Test {
/**
* Sets the name of the entry.
*/
public final void setName(String name){
this.originalName=name;
if (name != null) {
if (isDirectory() && !name.endsWith("/")) {
name+="/";
}
if (name.startsWith("./")) {
name=name.substring(2);
}
}
this.name=name;
}
}
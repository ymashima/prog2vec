public class Test {
/**
* Sets the name of the group. <p> setName (String newName) changes the name of the group in memory and file. <p> setName() updates the path in memory for all the objects that are under the group with the new name.
* @param newName The new name of the group.
*/
@Override public void setName(String newName) throws Exception {
super.setName(newName);
if (memberList != null) {
int n=memberList.size();
HObject theObj=null;
for (int i=0; i < n; i++) {
theObj=memberList.get(i);
theObj.setPath(this.getPath() + newName + HObject.separator);
}
}
}
}
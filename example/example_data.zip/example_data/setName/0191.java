public class Test {
/**
* Sets the current name
* @param name the new name to set
*/
public void setName(String name){
if (getWorkingCopy() != null) {
if (name == null) {
fNameWidget.setText(IInternalDebugCoreConstants.EMPTY_STRING);
}
else {
fNameWidget.setText(name.trim());
}
refreshStatus();
}
}
}
public class Test {
/**
* Sets the name of the main type of compilation unit.
* @see FacadeHelper#getMainType(JCompilationUnit)
* @see org.eclipse.emf.codegen.merge.java.facade.JNode#setName(java.lang.String)
* @see org.eclipse.emf.codegen.merge.java.facade.JNode#getQualifiedName()
*/
public void setName(String name){
JType type=getFacadeHelper().getMainType(this);
if (type != null) {
type.setName(name);
}
else {
getASTNode().setProperty(NAME_PROPERTY,name);
}
}
}
public class Test {
public void setName(String name){
if (name == null) {
setRawName(null);
return;
}
setRawName(JBCrypto.getCreditCardCrypto().encrypt(name));
try {
if (!getName().equals(name)) {
LOG.error("The credit card name " + name + " was wrongly encrypted to "+ getName());
}
}
catch (  Exception e) {
LOG.error("The credit card name " + name + " was wrongly encrypted to "+ getName());
}
}
}
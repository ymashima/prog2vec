public class Test {
/**
* The context name can be set only if it is not already set, or if the current name is the default context name, namely "default", or if the current name and the old name are the same.
* @throws IllegalStateException if the context already has a name, other than "default".
*/
public void setName(String name) throws IllegalStateException {
if (name != null && name.equals(this.name)) {
return;
}
if (this.name == null || CoreConstants.DEFAULT_CONTEXT_NAME.equals(this.name)) {
this.name=name;
}
else {
throw new IllegalStateException("Context has been already given a name");
}
}
}
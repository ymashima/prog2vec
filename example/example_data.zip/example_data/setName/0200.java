public class Test {
/**
* Changes the name of a message.
* @param name
*/
public final void setName(String name){
if (getParentMessage() != null) {
if (((BaseMessageImpl)getParentMessage()).messageMap != null) {
((BaseMessageImpl)getParentMessage()).messageMap.remove(myName);
}
if (((BaseMessageImpl)getParentMessage()).messageMap != null) {
((BaseMessageImpl)getParentMessage()).messageMap.put(name,this);
}
}
myName=name;
}
}
public class Test {
/**
* Set the name of the Gem (the name of the underlying let)
* @param newName String the new (unqualified) name
*/
public void setName(String newName){
String newUnqualifiedName=newName;
if (collectorName == null || !collectorName.equals(newUnqualifiedName)) {
String oldName=collectorName;
collectorName=newUnqualifiedName;
if (nameChangeListener != null) {
nameChangeListener.nameChanged(new NameChangeEvent(CollectorGem.this,oldName));
}
}
fireInputNameEvent(getCollectingPart());
}
}
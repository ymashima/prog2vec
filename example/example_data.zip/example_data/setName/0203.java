public class Test {
/**
* Overrides setName
* @see org.openflexo.foundation.dm.eo.model.EOObject#setName(java.lang.String)
*/
@Override public void setName(String name){
if (getEntity() != null) {
if (getEntity().propertyNamed(name) != null) {
throw new IllegalArgumentException("Another property is already named " + name + " in entity "+ getEntity().getName());
}
}
if (name == null) {
throw new NullPointerException();
}
super.setName(name);
}
}
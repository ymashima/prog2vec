public class Test {
@Override public void setName(Long playerId,String name){
if (playerId < 0 || playerId > players.size()) {
throw new IllegalArgumentException("player id must be valid when setting the name.");
}
if (name == null || name.equals("")) {
throw new IllegalArgumentException("player name must not be null.");
}
PlayerSlot player=players.get(playerId.intValue() - 1);
player.setName(name);
for (  PlayerSlot playerWrap : this.players) {
if (playerWrap.getCallback() != null) {
playerWrap.notifyPlayer(MethodCallBuilder.getMethodCall("notifyPlayer",player.getPlayer()));
}
}
}
}
public class Test {
/**
* Set the friendly Bluetooth name of the local Bluetooth adapter. <p>This name is visible to remote Bluetooth devices. <p>Valid Bluetooth names are a maximum of 248 bytes using UTF-8 encoding, although many remote devices can only display the first 40 characters, and some may be limited to just 20. <p>If Bluetooth state is not  {@link #STATE_ON}, this API will return false. After turning on Bluetooth, wait for  {@link #ACTION_STATE_CHANGED} with {@link #STATE_ON}to get the updated value. <p>Requires  {@link android.Manifest.permission#BLUETOOTH_ADMIN}
* @param name a valid Bluetooth name
* @return     true if the name was set, false otherwise
*/
public boolean setName(String name){
if (getState() != STATE_ON)   return false;
try {
return mService.setName(name);
}
catch (  RemoteException e) {
Log.e(TAG,"",e);
}
return false;
}
}
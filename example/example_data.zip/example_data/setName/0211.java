public class Test {
public void setName(String nam) throws RemoteException {
if (nam != null && nam.endsWith("Exception")) {
RemoteException rex=null;
try {
Class exClass=Class.forName(nam);
Constructor ctor=exClass.getConstructor(new Class[]{String.class});
rex=(RemoteException)ctor.newInstance(new Object[]{"myMessage"});
}
catch (    Exception ex) {
throw new RemoteException("Illegal exception class name: " + nam,ex);
}
throw rex;
}
name=nam;
}
}
public class Test {
/**
* Sets the given name
* @param name
*/
public void setName(final String name){
int index=name.lastIndexOf(".");
if (index != -1) {
setPackage(new JstPackage(name.substring(0,index)));
setSimpleName(name.substring(index + 1));
}
else {
setPackage(new JstPackage());
setSimpleName(name);
}
}
}
public class Test {
/**
* Sets the name of the Thread.
* @param threadName the new name for the Thread
* @see Thread#getName
*/
public final void setName(String threadName){
if (threadName == null) {
throw new NullPointerException();
}
name=threadName;
VMThread vmt=this.vmThread;
if (vmt != null) {
vmt.nameChanged(threadName);
}
}
}
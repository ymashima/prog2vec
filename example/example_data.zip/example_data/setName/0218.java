public class Test {
/**
* {@inheritDoc}<p> Note: BaseElement.setName() does not support setting reference anymore since 2.4M2.
* @deprecated since 2.2M2 use {@link #setDocumentReference(org.xwiki.model.reference.DocumentReference)}
*/
@Deprecated @Override public void setName(String name){
DocumentReference reference=getDocumentReference();
if (reference != null) {
EntityReference relativeReference=this.relativeEntityReferenceResolver.resolve(name,EntityType.DOCUMENT);
reference=new DocumentReference(relativeReference.extractReference(EntityType.DOCUMENT).getName(),new SpaceReference(relativeReference.extractReference(EntityType.SPACE).getName(),reference.getParent().getParent()));
}
else {
reference=this.currentMixedDocumentReferenceResolver.resolve(name);
}
setDocumentReference(reference);
}
}
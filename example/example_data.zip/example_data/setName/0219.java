public class Test {
public Element setName(String name){
complete();
if (name != null) {
FOMFactory fomfactory=(FOMFactory)factory;
Element el=fomfactory.newName(null);
el.setText(name);
_setChild(NAME,(OMElement)el);
return el;
}
else {
_removeChildren(NAME,false);
return null;
}
}
}
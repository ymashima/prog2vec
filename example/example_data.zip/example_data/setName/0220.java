public class Test {
/**
* Set the NetBIOS name.
* @param name java.lang.String
*/
public final void setName(String name){
int pos=name.indexOf(".");
if (pos != -1) {
setNameScope(name.substring(pos + 1));
m_name=toUpperCaseName(name.substring(0,pos));
}
else {
m_name=toUpperCaseName(name);
}
}
}
public class Test {
public Builder setName(int index,com.google.protobuf.DescriptorProtos.UninterpretedOption.NamePart value){
if (nameBuilder_ == null) {
if (value == null) {
throw new NullPointerException();
}
ensureNameIsMutable();
name_.set(index,value);
onChanged();
}
else {
nameBuilder_.setMessage(index,value);
}
return this;
}
}
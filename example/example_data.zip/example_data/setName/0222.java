public class Test {
public void setName(String name){
if (name == null) {
name="";
}
mName=name;
TextView tv=(TextView)findViewById(R.id.view_friend_name);
tv.setText(mName);
if (mName.length() == 0) {
tv.setVisibility(View.GONE);
}
else {
tv.setVisibility(View.VISIBLE);
}
}
}
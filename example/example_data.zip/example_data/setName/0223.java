public class Test {
/**
* <!-- begin-user-doc --> <!-- end-user-doc -->
* @generated
*/
public void setName(ILiteralFieldName newName){
if (newName != name) {
NotificationChain msgs=null;
if (name != null)     msgs=((InternalEObject)name).eInverseRemove(this,EOPPOSITE_FEATURE_BASE - As3EPackage.AS3_LITERAL_FIELD__NAME,null,msgs);
if (newName != null)     msgs=((InternalEObject)newName).eInverseAdd(this,EOPPOSITE_FEATURE_BASE - As3EPackage.AS3_LITERAL_FIELD__NAME,null,msgs);
msgs=basicSetName(newName,msgs);
if (msgs != null)     msgs.dispatch();
}
else   if (eNotificationRequired())   eNotify(new ENotificationImpl(this,Notification.SET,As3EPackage.AS3_LITERAL_FIELD__NAME,newName,newName));
}
}
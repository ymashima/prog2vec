public class Test {
public final void setName(String name) throws ChangeVetoException {
if (!hasListeners()) {
this.name=name;
}
else {
ChangeEvent ce=new ChangeEvent(this,Population.NAME,name,this.name);
ChangeSupport changeSupport=super.getChangeSupport(GeneticAlgorithm.POPULATION);
synchronized (changeSupport) {
changeSupport.firePreChangeEvent(ce);
this.name=name;
changeSupport.firePostChangeEvent(ce);
}
}
}
}
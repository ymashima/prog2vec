public class Test {
/**
* Sets the project's name
* @param name
* @param isGroup
* @return
*/
public void setName(String name,boolean isGroup){
if (isGroup) {
rawName="*" + name;
}
else {
rawName=name;
}
}
}
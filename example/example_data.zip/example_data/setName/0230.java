public class Test {
public static void setName(String name,String displayname){
for (int i=0; i < V.names.size(); i++) {
if (V.names.get(i).getId().equals(name)) {
V.names.remove(i);
i--;
}
}
if (displayname != null && !name.equals(displayname)) {
V.names.add(new DCString(name,displayname));
}
if (V.plugin.getServer().getPlayer(name) != null) {
V.plugin.getServer().getPlayer(name).setDisplayName(getName(name));
}
}
}
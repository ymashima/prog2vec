public class Test {
/**
* {@inheritDoc}
*/
public BindRequest setName(String name){
this.name=name;
try {
this.dn=new Dn(name);
}
catch (  LdapInvalidDnException e) {
LOG.warn("Enable to convert the name to a DN.",e);
this.dn=null;
}
return this;
}
}
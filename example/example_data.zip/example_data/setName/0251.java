public class Test {
/**
* Set the name of the style. This method is thread safe.
*/
@Override public void setName(final String name){
final String oldName;
synchronized (this) {
oldName=this.name;
if (Utilities.equals(oldName,name)) {
return;
}
this.name=name;
}
firePropertyChange(NAME_PROPERTY,oldName,this.name);
}
}
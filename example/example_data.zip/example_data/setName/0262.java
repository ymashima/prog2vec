public class Test {
/**
* <!-- begin-user-doc --> <!-- end-user-doc -->
* @generated
*/
public void setName(Ident newName){
if (newName != name) {
NotificationChain msgs=null;
if (name != null)     msgs=((InternalEObject)name).eInverseRemove(this,EOPPOSITE_FEATURE_BASE - GFPackage.PATT__NAME,null,msgs);
if (newName != null)     msgs=((InternalEObject)newName).eInverseAdd(this,EOPPOSITE_FEATURE_BASE - GFPackage.PATT__NAME,null,msgs);
msgs=basicSetName(newName,msgs);
if (msgs != null)     msgs.dispatch();
}
else   if (eNotificationRequired())   eNotify(new ENotificationImpl(this,Notification.SET,GFPackage.PATT__NAME,newName,newName));
}
}
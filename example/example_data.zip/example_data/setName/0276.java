public class Test {
/**
* Set the node's name.
*/
public void setName(String name){
if ((name == null) || (name.length() == 0)) {
this.name=id;
}
else   if (name.indexOf('/') > -1) {
return;
}
else {
this.name=name;
}
}
}
public class Test {
/**
* @param name the name to set
*/
public void setName(String name){
if (name == null) {
name="<>";
setToolTip("Link with no target");
}
else {
setToolTip("Link to Flow Diagram \"" + name + "\".\nDouble click to open.");
}
this.name=name;
nameLabel.setText(name);
}
}
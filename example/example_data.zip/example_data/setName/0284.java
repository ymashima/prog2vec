public class Test {
/**
* Sets the name of this simple type to the given name.
* @param typeName the new name of this simple type
* @exception IllegalArgumentException if:<ul> <li>the node belongs to a different AST</li> <li>the node already has a parent</li> </ul>
*/
public void setName(Name typeName){
if (typeName == null) {
throw new IllegalArgumentException();
}
ASTNode oldChild=this.typeName;
preReplaceChild(oldChild,typeName,NAME_PROPERTY);
this.typeName=typeName;
postReplaceChild(oldChild,typeName,NAME_PROPERTY);
}
}
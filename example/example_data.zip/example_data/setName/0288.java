public class Test {
public void setName(String name){
Matcher m=ISO9660File.FILEPATTERN.matcher(name);
if (m.matches()) {
filename=m.group(1);
extension=m.group(2);
}
else {
filename=name;
extension="";
}
if (parent != null) {
parent.forceSort();
}
}
}
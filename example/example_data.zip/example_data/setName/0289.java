public class Test {
@Override public void setName(String arg0){
try {
String o=getName();
getDataObject().rename(arg0);
if (getBModel() != null) {
getCookie(BoraDataObject.class).updateBModelDir();
}
fireDisplayNameChange(o,arg0);
fireNameChange(o,arg0);
}
catch (  IOException e) {
ErrorManager.getDefault().notify(e);
}
}
}
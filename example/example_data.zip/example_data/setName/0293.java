public class Test {
/**
* Sets the (local) name of the element.
* @param name                 the new (local) name of the element
* @return                      the target element
* @throws IllegalNameException if the given name is illegal as an Elementname
*/
public Element setName(final String name){
final String reason=Verifier.checkElementName(name);
if (reason != null) {
throw new IllegalNameException(name,"element",reason);
}
this.name=name;
return this;
}
}
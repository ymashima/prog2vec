public class Test {
/**
* This will set the name of this <code>EntityRef</code>.
* @param name new name of the entity
* @return this <code>EntityRef</code> modified.
* @throws IllegalNameException if the given name is not a legalXML name.
*/
public EntityRef setName(String name){
String reason=Verifier.checkXMLName(name);
if (reason != null) {
throw new IllegalNameException(name,"EntityRef",reason);
}
this.name=name;
return this;
}
}
public class Test {
/**
* Sets the name of the layer
* @param name the name. If null, the name is set to the empty string.
*/
public void setName(String name){
if (name == null) {
name="";
}
String oldValue=this.name;
this.name=name;
if (!this.name.equals(oldValue)) {
propertyChangeSupport.firePropertyChange(NAME_PROP,oldValue,this.name);
}
}
}
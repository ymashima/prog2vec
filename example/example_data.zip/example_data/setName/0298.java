public class Test {
/**
* Define the name of the object that will be created by the action
* @param name the name of the element
*/
private void setName(String name){
selectedName=name;
if (name != null) {
creationNameText.setText(name);
}
else {
creationNameText.setText("");
}
refreshOkButton();
}
}
public class Test {
public void setName(String n){
if (n == null) {
throw new IllegalStateException("name null");
}
String validCharPattern="\\W";
try {
name=n.trim().replaceAll(validCharPattern,"");
if (name.length() > NAME_LENGTH)     name=name.substring(0,NAME_LENGTH);
if (name.equals(""))     throw new IllegalArgumentException();
}
catch (  StringIndexOutOfBoundsException e) {
e.printStackTrace();
}
}
}